#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf results/* ht_trim build
find . -name '__pycache__' -type d -prune -exec rm -rf {} +
