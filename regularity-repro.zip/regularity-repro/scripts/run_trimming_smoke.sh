#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
make
python3 tests/test_ht_trim_engine.py
python3 -m py_compile python/*.py
python3 python/run_paper_success_suite.py \
  --profile smoke \
  --skip-ph \
  --out-dir results/trimming_smoke \
  --trim-timeout 120
