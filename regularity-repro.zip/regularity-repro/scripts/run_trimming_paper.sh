#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
make
python3 python/run_paper_success_suite.py \
  --profile paper \
  --out-dir results/trimming_paper \
  --ph-timeout 3600 \
  --trim-timeout 3600 \
  --count-simplices auto \
  --resume \
  "$@"
