#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 python/rsd_synthetic_descriptor_experiment.py \
  --out-dir results/rsd_structure \
  --num-seeds 20
