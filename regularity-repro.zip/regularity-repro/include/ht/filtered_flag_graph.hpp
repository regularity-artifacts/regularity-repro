#pragma once

#include <algorithm>
#include <array>
#include <vector>

namespace ht {

// A filtered flag graph used for internal local complexes such as lower links.
//
// The global input graph is represented by WeightedGraph.  Lower links are more
// general: vertices have nontrivial birth times alpha(q), and edges have birth
// times beta(q,r).  This type is the internal bridge toward recursive lower-link
// computations and general-K rank-sweep oracles.
struct FFVertex {
    int q = -1;              // original/global vertex id, or local id in recursive calls
    double alpha = 0.0;      // vertex birth time
};

struct FFEdge {
    int a = -1;
    int b = -1;
    double beta = 0.0;       // edge birth time
};

struct FFTriangle {
    int a = -1;
    int b = -1;
    int c = -1;
    double gamma = 0.0;      // triangle birth time
};

struct FFTetrahedron {
    int a = -1;
    int b = -1;
    int c = -1;
    int d = -1;
    double delta = 0.0;      // tetrahedron birth time
};

class FilteredFlagGraph {
public:
    std::vector<FFVertex> V;
    std::vector<FFEdge> E;
    std::vector<FFTriangle> T;
    std::vector<FFTetrahedron> Q;

    // Flattened local m x m edge lookup. -1 means absent.
    std::vector<int> edge_id;

    // Flattened sorted local m x m x m triangle lookup. -1 means absent.
    // The lookup function sorts the three indices, so only one canonical
    // position is populated.
    std::vector<int> triangle_id;

    void clear();
    void init_edge_lookup(int m);
    void init_triangle_lookup(int m);
    int lookup_index(int i, int j) const;
    int triangle_lookup_index(int i, int j, int k) const;
    int local_edge_id(int i, int j) const;
    int local_triangle_id(int i, int j, int k) const;
    void set_local_edge_id(int i, int j, int id);
    void set_local_triangle_id(int i, int j, int k, int id);

    int num_vertices() const { return static_cast<int>(V.size()); }
    int num_edges() const { return static_cast<int>(E.size()); }
    int num_triangles() const { return static_cast<int>(T.size()); }
    int num_tetrahedra() const { return static_cast<int>(Q.size()); }
    int num_simplices_2_skeleton() const { return num_vertices() + num_edges() + num_triangles(); }
    int num_simplices_3_skeleton() const { return num_vertices() + num_edges() + num_triangles() + num_tetrahedra(); }
};

// Backward-compatible aliases used by the current K<=2 code.
using LLVertex = FFVertex;
using LLEdge = FFEdge;
using LLTriangle = FFTriangle;
using LowerLink2 = FilteredFlagGraph;

} // namespace ht
