#pragma once

#include "ht/edge.hpp"
#include "ht/options.hpp"
#include "ht/stats.hpp"

#include <string>
#include <vector>

namespace ht {

std::vector<Edge> read_edges(const std::string& path);
void write_report(const std::string& path, const Options& opt, const Stats& st);
std::string json_escape(const std::string& s);
void usage();

} // namespace ht
