#pragma once

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <string>
#include <utility>

namespace ht {

static constexpr double EPS = 1e-12;
using EdgeId = int;

inline uint64_t key_edge(int a, int b) {
    if (a > b) std::swap(a, b);
    return (static_cast<uint64_t>(static_cast<uint32_t>(a)) << 32)
         | static_cast<uint32_t>(b);
}

inline double now_seconds() {
    using clock = std::chrono::steady_clock;
    static const auto t0 = clock::now();
    return std::chrono::duration<double>(clock::now() - t0).count();
}

inline bool leq_filtration(double a, double b) {
    return a <= b + EPS;
}

inline bool filtration_less(double a, double b) {
    return std::abs(a - b) > EPS && a < b;
}

} // namespace ht
