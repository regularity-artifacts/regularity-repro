#pragma once

#include "ht/common.hpp"
#include "ht/dsu.hpp"
#include "ht/general_link.hpp"
#include "ht/graph.hpp"
#include "ht/lower_link.hpp"
#include "ht/options.hpp"
#include "ht/stats.hpp"

#include <string>
#include <vector>

namespace ht {

class TrimEngine {
public:
    TrimEngine(WeightedGraph G, Options opt);

    Stats run();
    const WeightedGraph& graph() const { return G_; }

private:
    WeightedGraph G_;
    Options opt_;
    Stats st_;

    // Reusable scratch buffers for lower-link construction. Reusing these
    // (via LowerLink2::clear(), which retains vector capacity) avoids
    // repeated malloc/free churn on the O(m^2) local edge-lookup table that
    // would otherwise be reallocated from scratch on every single candidate
    // edge. scratch_link_ backs build_lower_link_1_skeleton() and is fully
    // consumed within a single k1_raw/k2_raw/k3_raw/homology_delay_decision
    // call before the next call begins. scratch_local_edge_link_ backs
    // build_local_edge_lower_link_1_skeleton() and is similarly fully
    // consumed within a single recursive-prefilter loop iteration; it is a
    // distinct buffer so it never aliases scratch_link_ even though the
    // outer link L is still alive (and read) while the local-edge link is
    // being built from it.
    mutable LowerLink2 scratch_link_;
    mutable LowerLink2 scratch_local_edge_link_;

    // Scratch buffer for the general-K (K>=4, and cross-validation for
    // K<=3) staged rank-sweep oracle. Reused across calls the same way
    // scratch_link_ is, via GeneralLowerLink::reset() retaining capacity.
    mutable GeneralLowerLink scratch_general_link_;

    std::vector<EdgeId> active_edges_in_order() const;

    bool domination_raw(EdgeId eid, int* apex_out) const;
    bool domination(EdgeId eid, int* apex_out);

    bool k0_raw(EdgeId eid, LinkSummary* L) const;
    bool k1_raw(EdgeId eid, LinkSummary* S);
    bool k2_raw(EdgeId eid, LinkSummary* S);
    bool k3_raw(EdgeId eid, LinkSummary* S);
    bool homology(EdgeId eid, LinkSummary* L);

    // General-K path: works for any K>=1 (used automatically for K>=4, and
    // available for K<=3 as a cross-validation reference against the
    // hand-specialized fast paths above). Returns the exact future time at
    // which H~_j(lower link)=0 (j=-1..K-1) first fails from x onward, or
    // +infinity if it never fails.
    GeneralLowerLink& build_general_lower_link(EdgeId eid) const;
    double homology_failure_time_general(GeneralLowerLink& L, double x, int K);
    bool insert_boundary_column_general(std::vector<int> col, std::vector<std::vector<int>>& basis);

    enum class DelayAction { Keep, Delay, Delete };
    struct DelayDecision {
        DelayAction action = DelayAction::Keep;
        double new_weight = 0.0;
        LinkSummary link;
    };
    DelayDecision homology_delay_decision(EdgeId eid);
    double first_h0_failure_time(LowerLink2 const& L, double x) const;
    double first_h1_failure_time(LowerLink2 const& L, double x);
    double first_h2_failure_time(LowerLink2 const& L, double x);

    LowerLink2& build_lower_link_1_skeleton(EdgeId eid) const;
    void build_lower_link_triangles(LowerLink2& L) const;
    void build_lower_link_tetrahedra(LowerLink2& L) const;

    bool lower_link_h0_future_connected(LowerLink2 const& L, double x) const;
    bool lower_link_h1_future_zero(LowerLink2 const& L, double x);
    bool lower_link_h2_future_zero(LowerLink2 const& L, double x);

    static std::vector<int> xor_sorted(std::vector<int> const& A, std::vector<int> const& B);
    static void xor_sorted_inplace(std::vector<int>& A, std::vector<int> const& B);
    bool insert_boundary_column(std::vector<int> col, std::vector<std::vector<int>>& basis, int boundary_dim);

    bool forest_future_connected_with_active_edges(LowerLink2 const& L,
                                                   std::vector<char> const& edge_active,
                                                   double x) const;
    LowerLink2& build_local_edge_lower_link_1_skeleton(LowerLink2 const& L,
                                                       std::vector<char> const& active_edge,
                                                       int local_eid) const;
    bool local_edge_k1_certifies(LowerLink2 const& L,
                                 std::vector<char> const& active_edge,
                                 int local_eid,
                                 double preserve_from) const;
    bool local_edge_k2_certifies(LowerLink2 const& L,
                                 std::vector<char> const& active_edge,
                                 int local_eid,
                                 double preserve_from);
    bool recursive_trim_prefilter_forest(LowerLink2 const& L, double x);
    bool recursive_trim_prefilter_forest_k2(LowerLink2 const& L, double x);

    void remove_record(EdgeId eid, std::string phase, int pass, std::string oracle, int apex, LinkSummary L);
    void delay_record(EdgeId eid, double new_weight, std::string phase, int pass, std::string oracle, LinkSummary L);

    void run_gudhi_collapse();

    void run_domination_until_stable();
    void run_homology_until_stable();
    void run_homology_delay_until_stable();
    void run_staged();
    void run_interleaved();
};

} // namespace ht
