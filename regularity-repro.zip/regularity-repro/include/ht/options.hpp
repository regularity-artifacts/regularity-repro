#pragma once

#include <stdexcept>
#include <string>

namespace ht {

enum class OracleMode { Domination, Homology, Hybrid, GudhiCollapse, HomologyDelay, HybridDelay };
enum class ScheduleMode { Staged, Interleaved };
enum class OrderMode { Reverse, Forward, Lex };
enum class K2PrefilterMode { None, RecursiveTrim };
enum class K3Mode { ExactRank, RecursivePrefilter, RecursiveOnly };

struct Options {
    int max_global_dim = 1;
    OracleMode oracle = OracleMode::Hybrid;
    ScheduleMode schedule = ScheduleMode::Staged;
    OrderMode order = OrderMode::Reverse;
    K2PrefilterMode k2_prefilter = K2PrefilterMode::None;
    K3Mode k3_mode = K3Mode::ExactRank;
    bool certificate = true;
    // Debug/verification flag: route every K>=1 through the general staged
    // rank-sweep oracle instead of the hand-specialized K=1/2/3 fast paths.
    // Used to cross-validate the two implementations against each other.
    bool force_general = false;
};

std::string to_string(OracleMode x);
std::string to_string(ScheduleMode x);
std::string to_string(OrderMode x);
std::string to_string(K2PrefilterMode x);
std::string to_string(K3Mode x);

OracleMode parse_oracle(const std::string& s);
ScheduleMode parse_schedule(const std::string& s);
OrderMode parse_order(const std::string& s);
K2PrefilterMode parse_k2_prefilter(const std::string& s);
K3Mode parse_k3_mode(const std::string& s);

} // namespace ht
