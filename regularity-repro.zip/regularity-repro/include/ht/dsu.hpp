#pragma once

#include <numeric>
#include <vector>
#include <algorithm>

namespace ht {

struct DSU {
    std::vector<int> p;
    std::vector<int> r;

    explicit DSU(int n = 0) { reset(n); }

    void reset(int n) {
        p.resize(n);
        r.assign(n, 0);
        std::iota(p.begin(), p.end(), 0);
    }

    int find(int x) {
        while (p[x] != x) {
            p[x] = p[p[x]];
            x = p[x];
        }
        return x;
    }

    bool unite(int a, int b) {
        int ra = find(a), rb = find(b);
        if (ra == rb) return false;
        if (r[ra] < r[rb]) std::swap(ra, rb);
        p[rb] = ra;
        if (r[ra] == r[rb]) ++r[ra];
        return true;
    }
};

} // namespace ht
