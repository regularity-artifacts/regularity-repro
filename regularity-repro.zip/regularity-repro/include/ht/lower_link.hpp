#pragma once

#include "ht/filtered_flag_graph.hpp"

namespace ht {

// LowerLink2 is currently an alias for FilteredFlagGraph.  This header is kept
// so existing K=0,1,2 code can use lower-link terminology while the internal
// representation is now general enough to support vertex birth times.

} // namespace ht
