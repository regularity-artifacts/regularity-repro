#pragma once

#include "ht/common.hpp"

namespace ht {

struct Edge {
    int u = -1;
    int v = -1;
    double w = 0.0;
    bool active = true;
    EdgeId id = -1;
};

} // namespace ht
