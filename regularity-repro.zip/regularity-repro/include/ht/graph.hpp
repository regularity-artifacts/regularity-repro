#pragma once

#include "ht/edge.hpp"

#include <string>
#include <unordered_map>
#include <vector>

namespace ht {

struct AdjEntry {
    int nbr = -1;
    EdgeId eid = -1;
};

class WeightedGraph {
public:
    WeightedGraph() = default;
    explicit WeightedGraph(const std::vector<Edge>& input);

    void build(const std::vector<Edge>& input);

    int n() const { return n_; }
    int m() const { return static_cast<int>(edges_.size()); }

    const Edge& edge(EdgeId id) const;
    const std::vector<Edge>& edges() const { return edges_; }
    bool active(EdgeId id) const;

    EdgeId edge_id(int u, int v) const;
    bool has_active_edge(int u, int v) const;
    double weight(int u, int v) const;

    // Combined lookup: returns true and writes the weight iff (u,v) is an
    // active edge. Equivalent to (has_active_edge(u,v) ? (*w = weight(u,v), true) : false)
    // but performs a single hashmap lookup instead of two. Used by the
    // lower-link builder, which looks up arbitrary (not-necessarily-adjacent)
    // pairs of local vertices where the merge-join tricks below don't apply.
    bool active_weight(int u, int v, double* w) const;

    void deactivate(EdgeId id);
    void set_weight(EdgeId id, double w);

    int active_edge_count() const;
    std::vector<EdgeId> active_edge_ids() const;
    std::vector<int> active_neighbors(int u) const;
    std::vector<int> active_common_neighbors(int u, int v) const;

    // Allocation-light primitives used by the fast domination oracle.
    // `common` is sorted increasingly by vertex id, and alpha[i] is
    // max(w(u,common[i]), w(v,common[i])) for the current active graph.
    void active_common_neighbors_with_alpha(int u, int v,
                                            std::vector<int>& common,
                                            std::vector<double>& alpha) const;

    // Return true iff c is adjacent, in the current active graph, to every
    // vertex common[i] except skip_index, with edge weight <= alpha[i].
    // The input `common` must be sorted increasingly.
    bool active_neighbors_cover_bounds(int c,
                                       const std::vector<int>& common,
                                       const std::vector<double>& alpha,
                                       int skip_index) const;

    void write_active_edges(const std::string& path) const;

private:
    int n_ = 0;
    std::vector<Edge> edges_;
    std::vector<std::vector<AdjEntry>> adj_;
    std::unordered_map<uint64_t, EdgeId> lookup_;
};

} // namespace ht
