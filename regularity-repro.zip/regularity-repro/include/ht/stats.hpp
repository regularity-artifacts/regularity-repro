#pragma once

#include <algorithm>
#include <string>
#include <vector>

namespace ht {

struct LinkSummary {
    int vertices = 0;
    int edges = 0;
    int triangles = 0;
    int tetrahedra = 0;
    int simplices = 0;
};

struct RemovedRecord {
    int u = -1;
    int v = -1;
    int apex = -1;
    int pass = 0;
    double w = 0.0;
    double new_w = 0.0;
    std::string phase;
    std::string oracle;
    std::string action = "remove";
    LinkSummary link;
};

struct Stats {
    int initial_edges = 0;
    int final_edges = 0;
    int removed_count = 0;

    int domination_removals = 0;
    int homology_removals = 0;
    int delayed_count = 0;
    int homology_delay_count = 0;
    double total_delay = 0.0;
    double max_delay = 0.0;

    long long domination_calls = 0;
    long long domination_success = 0;
    long long domination_fail = 0;

    long long ph_calls = 0;
    long long ph_success = 0;
    long long ph_fail = 0;

    double domination_seconds = 0.0;
    double ph_seconds = 0.0;

    // Coarse legacy timings.
    double ph_lower_link_seconds = 0.0;
    double ph_reduction_seconds = 0.0;

    // Dimension-resolved construction timings.
    // 1-skeleton includes local vertices and local edges.
    double build_1_skeleton_seconds = 0.0;
    double build_triangles_seconds = 0.0;
    double build_tetrahedra_seconds = 0.0;

    // Dimension-resolved rank/check timings.
    double connectivity_seconds = 0.0;
    double rank_boundary2_seconds = 0.0;
    double rank_boundary3_seconds = 0.0;

    // Boundary-column counters.  boundary2 means triangle boundaries -> edges.
    // boundary3 means tetrahedron boundaries -> triangles.
    long long boundary2_columns = 0;
    long long boundary3_columns = 0;
    long long boundary2_rank_increments = 0;
    long long boundary3_rank_increments = 0;
    long long boundary2_xor_ops = 0;
    long long boundary3_xor_ops = 0;

    // K=3 delayed-∂3 feasibility diagnostics.
    long long boundary3_feasibility_rejects = 0;
    long long boundary3_skipped_after_zero = 0;

    // General-K (K>=4) staged rank-sweep diagnostics. Lumped across all
    // dimensions >=2 rather than one field per dimension, since K is now
    // unbounded; per-dimension detail for K<=3 still lives in the fields
    // above (populated by the hand-specialized K<=3 fast paths).
    long long boundary_general_columns = 0;
    long long boundary_general_rank_increments = 0;
    long long boundary_general_xor_ops = 0;
    long long boundary_general_feasibility_rejects = 0;
    long long boundary_general_skipped_after_zero = 0;
    double rank_boundary_general_seconds = 0.0;
    double build_general_levels_seconds = 0.0;

    long long recursive_prefilter_calls = 0;
    long long recursive_prefilter_success = 0;
    long long recursive_prefilter_fail = 0;
    long long recursive_prefilter_edge_tests = 0;
    long long recursive_prefilter_edge_removals = 0;
    double recursive_prefilter_seconds = 0.0;

    long long sum_link_vertices = 0;
    long long sum_link_edges = 0;
    long long sum_link_triangles = 0;
    long long sum_link_tetrahedra = 0;
    long long sum_link_simplices = 0;

    int max_link_vertices = 0;
    int max_link_edges = 0;
    int max_link_triangles = 0;
    int max_link_tetrahedra = 0;
    int max_link_simplices = 0;

    std::vector<RemovedRecord> removed_edges;

    void observe_link(LinkSummary const& L) {
        sum_link_vertices += L.vertices;
        sum_link_edges += L.edges;
        sum_link_triangles += L.triangles;
        sum_link_tetrahedra += L.tetrahedra;
        sum_link_simplices += L.simplices;
        max_link_vertices = std::max(max_link_vertices, L.vertices);
        max_link_edges = std::max(max_link_edges, L.edges);
        max_link_triangles = std::max(max_link_triangles, L.triangles);
        max_link_tetrahedra = std::max(max_link_tetrahedra, L.tetrahedra);
        max_link_simplices = std::max(max_link_simplices, L.simplices);
    }
};

} // namespace ht
