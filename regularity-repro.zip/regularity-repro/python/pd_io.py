#!/usr/bin/env python3
"""
Shared helpers for run_ripser_only.py and run_pipeline.py, so both scripts
write persistence diagrams to disk in exactly the same plain-text format
and are trivially diff-able / hand-comparable by the user.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from scipy import sparse


def read_edges(path: Path):
    edges = []
    max_v = -1
    for line in Path(path).read_text().splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        u, v, w = line.split()
        u, v = int(u), int(v)
        edges.append((u, v, float(w)))
        max_v = max(max_v, u, v)
    return edges, max_v + 1


def write_edges(path: Path, edges) -> None:
    with Path(path).open("w") as f:
        for u, v, w in sorted(edges):
            f.write(f"{u} {v} {w:.17g}\n")


def sparse_matrix_from_edges(n: int, edges):
    rows, cols, vals = [], [], []
    maxw = 0.0
    for u, v, w in edges:
        rows.extend([u, v]); cols.extend([v, u]); vals.extend([w, w])
        maxw = max(maxw, w)
    D = sparse.coo_matrix((vals, (rows, cols)), shape=(n, n)).tocsr()
    return D, maxw


def clean_bars(dgms, d, thresh):
    """Bars for dimension d: dropped if zero-length or born after thresh,
    rounded to 6 decimals and sorted, so two runs are byte-comparable."""
    if d >= len(dgms):
        return []
    out = []
    for b, e in dgms[d]:
        b, e = float(b), float(e)
        if b > thresh + 1e-6:
            continue
        if not np.isinf(e) and e - b <= 1e-6:
            continue
        out.append((round(b, 6), None if np.isinf(e) else round(e, 6)))
    out.sort(key=lambda x: (x[0], float("inf") if x[1] is None else x[1]))
    return out


def write_pd_file(path: Path, header_lines, dgms, maxdim, thresh):
    """Write a plain-text PD file: '#'-prefixed metadata header, then one
    'dim <d>' section per dimension with one 'birth death' pair per line
    (death is the literal string 'inf' for essential classes)."""
    lines = [f"# {h}" for h in header_lines]
    lines.append("#")
    for d in range(maxdim + 1):
        bars = clean_bars(dgms, d, thresh)
        lines.append(f"# dim {d} ({len(bars)} bars)")
        for b, e in bars:
            e_str = "inf" if e is None else f"{e:.6f}"
            lines.append(f"{b:.6f} {e_str}")
        lines.append("#")
    Path(path).write_text("\n".join(lines) + "\n")
