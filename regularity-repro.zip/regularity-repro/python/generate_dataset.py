#!/usr/bin/env python3
"""
Generate one edge-list dataset file, so the exact same input can be fed to
both run_ripser_only.py and run_pipeline.py for a fair side-by-side check.

Usage:
    python3 python/generate_dataset.py --n 100 --seed 7 --out data1.txt
    python3 python/generate_dataset.py --n 60 --seed 3 --family matrix --out data2.txt

Output format: one edge per line, "u v weight" (0-indexed vertices, complete
graph -- every pair of vertices appears exactly once).
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np


def geometric_edges(n: int, seed: int, dim: int = 2):
    rng = np.random.default_rng(seed)
    pts = rng.random((n, dim))
    diff = pts[:, None, :] - pts[None, :, :]
    D = np.sqrt(np.sum(diff * diff, axis=2))
    return [(i, j, float(D[i, j])) for i in range(n) for j in range(i + 1, n)]


def matrix_edges(n: int, seed: int):
    rng = np.random.default_rng(seed)
    W = rng.random((n, n))
    return [(i, j, float(W[i, j])) for i in range(n) for j in range(i + 1, n)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, required=True, help="number of vertices")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--family", choices=["geometric", "matrix"], default="geometric")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    edges = geometric_edges(args.n, args.seed) if args.family == "geometric" \
        else matrix_edges(args.n, args.seed)

    out_path = Path(args.out)
    with out_path.open("w") as f:
        for u, v, w in sorted(edges):
            f.write(f"{u} {v} {w:.17g}\n")

    print(f"wrote {len(edges)} edges, {args.n} vertices ({args.family}) to {out_path}")


if __name__ == "__main__":
    main()
