#!/usr/bin/env python3
"""Synthetic RSD structural-descriptor experiment for anonymous reproduction.

The script generates three synthetic families of edge-filtered graphs, computes
edge-level RSD summaries under the p=2 lower-link criterion, and writes the
graph-level descriptor tables used in the preliminary-application appendix.
"""
import random, math, itertools, csv, statistics, os
from collections import defaultdict, Counter
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------- GF(2) rank ----------
def gf2_rank(rows):
    # rows are Python ints bitsets
    basis = {}
    rank = 0
    for x in rows:
        y = x
        while y:
            p = y.bit_length() - 1
            if p in basis:
                y ^= basis[p]
            else:
                basis[p] = y
                rank += 1
                break
    return rank

# ---------- Graph representation ----------
def add_edge(W, u, v, w):
    if u == v: return
    if u > v: u, v = v, u
    W[(u,v)] = float(w)

def has_edge(W, u, v):
    if u > v: u, v = v, u
    return (u,v) in W

def get_w(W, u, v):
    if u > v: u, v = v, u
    return W[(u,v)]

def neighbors(W, n):
    N = [set() for _ in range(n)]
    for (u,v),w in W.items():
        N[u].add(v); N[v].add(u)
    return N

# ---------- Synthetic families ----------
def gen_clique_rich(seed, blocks=8, b=10, cross_p=0.01):
    rng = random.Random(seed)
    n = blocks*b
    W = {}
    # complete blocks with broad weights; local links often become filled/acyclic
    for B in range(blocks):
        verts = list(range(B*b,(B+1)*b))
        for u,v in itertools.combinations(verts,2):
            add_edge(W,u,v,rng.random())
    # small amount of cross noise
    for u in range(n):
        for v in range(u+1,n):
            if u//b != v//b and rng.random() < cross_p:
                add_edge(W,u,v,0.7+0.3*rng.random())
    return n,W

def gen_cycle_rich(seed, gadgets=12, r=7, noise_p=0.003):
    rng = random.Random(seed)
    n = gadgets*(r+2)
    W = {}
    anchors = []
    for g in range(gadgets):
        base = g*(r+2)
        u,v = base, base+1
        qs = list(range(base+2, base+2+r))
        anchors.append((u,v))
        # anchor edge inside the acyclic window
        add_edge(W,u,v,0.50 + 0.02*rng.random())
        # common-neighbor vertices appear before anchor
        for q in qs:
            add_edge(W,u,q,0.10+0.20*rng.random())
            add_edge(W,v,q,0.10+0.20*rng.random())
        # path edges appear before anchor: lower link is a tree/path
        for a,b in zip(qs[:-1], qs[1:]):
            add_edge(W,a,b,0.25+0.15*rng.random())
        # closing edge appears after anchor: creates an H1 blocker
        add_edge(W,qs[-1],qs[0],0.68+0.08*rng.random())
    # sparse inter-gadget noise
    for u in range(n):
        for v in range(u+1,n):
            if not has_edge(W,u,v) and rng.random() < noise_p:
                add_edge(W,u,v,rng.random())
    return n,W

def gen_sparse_random(seed, n=90, avg_deg=10):
    rng = random.Random(seed)
    W = {}
    p = avg_deg/(n-1)
    for u in range(n):
        for v in range(u+1,n):
            if rng.random() < p:
                add_edge(W,u,v,rng.random())
    return n,W

# ---------- Lower-link homology up to H1 ----------
def lower_link_data(n,W,e):
    u,v = e
    if u>v: u,v=v,u
    N = neighbors(W,n)
    common = sorted(N[u].intersection(N[v]) - {u,v})
    vt = {}
    for q in common:
        vt[q] = max(get_w(W,u,q), get_w(W,v,q))
    le = {}
    for q,r in itertools.combinations(common,2):
        if has_edge(W,q,r):
            le[(q,r)] = max(vt[q], vt[r], get_w(W,q,r))
    tri = {}
    for a,b,c in itertools.combinations(common,3):
        pairs = [(min(a,b),max(a,b)),(min(a,c),max(a,c)),(min(b,c),max(b,c))]
        if all(p in le for p in pairs):
            tri[(a,b,c)] = max(vt[a], vt[b], vt[c], *(le[p] for p in pairs))
    return common, vt, le, tri

def betti_link_at(data, t):
    common, vt, le, tri = data
    verts = [q for q in common if vt[q] <= t]
    if not verts:
        return {-1:1, 0:0, 1:0}
    vid = {q:i for i,q in enumerate(verts)}
    edges = [(q,r) for (q,r),tm in le.items() if tm <= t and q in vid and r in vid]
    parent = list(range(len(verts)))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a,b):
        ra,rb = find(a),find(b)
        if ra != rb: parent[rb] = ra
    for q,r in edges:
        union(vid[q],vid[r])
    comps = len({find(i) for i in range(len(verts))})
    beta0 = comps - 1
    # H1 = m - n + comps - rank(d2)
    eid = {e:i for i,e in enumerate(edges)}
    rows = []
    for (a,b,c),tm in tri.items():
        if tm <= t and a in vid and b in vid and c in vid:
            pairs = [(min(a,b),max(a,b)),(min(a,c),max(a,c)),(min(b,c),max(b,c))]
            if all(p in eid for p in pairs):
                bit = 0
                for p in pairs:
                    bit ^= (1 << eid[p])
                rows.append(bit)
    rank_d2 = gf2_rank(rows)
    beta1 = len(edges) - len(verts) + comps - rank_d2
    return {-1:0, 0:beta0, 1:beta1}

def regular_for_p(betti, p=2):
    # Edge e, dim(e)=1. Preserve global H_0..H_p requires lower-link H_j=0 for j=-1..p-1.
    return all(betti[j] == 0 for j in range(-1,p))

def first_blocker_dim(betti, p=2):
    for j in range(-1,p):
        if betti[j] != 0:
            return j
    return None

def rsd_for_edge(n,W,e,p=2):
    x = get_w(W,*e)
    data = lower_link_data(n,W,e)
    common,vt,le,tri=data
    events = sorted(set(list(vt.values()) + list(le.values()) + list(tri.values())))
    starts = [-math.inf] + events
    ends = events + [math.inf]
    statuses=[]; blockers=[]
    for i,(a,b) in enumerate(zip(starts,ends)):
        if a == -math.inf:
            rep = b - 1.0 if b < math.inf else x
        else:
            rep = a + 1e-10
        bet = betti_link_at(data, rep)
        statuses.append(regular_for_p(bet,p))
        blockers.append(first_blocker_dim(bet,p))
    # find interval containing x: start <= x < end
    idx=None
    for i,(a,b) in enumerate(zip(starts,ends)):
        if (a == -math.inf or x >= a - 1e-12) and (b == math.inf or x < b - 1e-12):
            idx=i; break
    if idx is None:
        idx=len(starts)-1
    reg = statuses[idx]
    if not reg:
        return dict(edge=e,x=x,regular=False)
    Lidx=idx
    while Lidx>0 and statuses[Lidx-1]: Lidx-=1
    Ridx=idx
    while Ridx<len(statuses)-1 and statuses[Ridx+1]: Ridx+=1
    ell = starts[Lidx]
    rr = ends[Ridx]
    left_slack = math.inf if ell == -math.inf else x-ell
    right_slack = math.inf if rr == math.inf else rr-x
    left_blocker = blockers[Lidx-1] if Lidx>0 else None
    right_blocker = blockers[Ridx+1] if Ridx < len(statuses)-1 else None
    return dict(edge=e,x=x,regular=True,ell=ell,r=rr,L=left_slack,R=right_slack,margin=min(left_slack,right_slack),left_blocker=left_blocker,right_blocker=right_blocker)

def actual_safe(n,W,e,p,delta):
    # sample every interval between x and x+delta; safe iff all statuses along closed path are regular
    x=get_w(W,*e); y=x+delta
    lo=min(x,y); hi=max(x,y)
    data=lower_link_data(n,W,e)
    common,vt,le,tri=data
    events=sorted(set(list(vt.values())+list(le.values())+list(tri.values())+[lo,hi]))
    # check representative points just to right of every event inside [lo,hi), plus hi
    reps=[]
    for ev in events:
        if lo <= ev <= hi:
            reps.append(ev+1e-10)
    reps.append(hi)
    for t in reps:
        if lo-1e-9 <= t <= hi+1e-9:
            if not regular_for_p(betti_link_at(data,t),p):
                return False
    return True

def summarize_graph(family, seed, n,W,p=2):
    rows=[]
    for e in W.keys():
        rows.append(rsd_for_edge(n,W,e,p))
    reg=[r for r in rows if r.get('regular')]
    finite=lambda x: not math.isinf(x)
    def med(vals): return float(np.median(vals)) if vals else 0.0
    def q(vals,q): return float(np.quantile(vals,q)) if vals else 0.0
    margins=[r['margin'] for r in reg if finite(r['margin'])]
    Ls=[r['L'] for r in reg if finite(r['L'])]
    Rs=[r['R'] for r in reg if finite(r['R'])]
    rb=Counter(r['right_blocker'] for r in reg if r.get('right_blocker') is not None)
    lb=Counter(r['left_blocker'] for r in reg if r.get('left_blocker') is not None)
    return {
        'family':family, 'seed':seed, 'n':n, 'm':len(W), 'regular_edges':len(reg),
        'regular_frac':len(reg)/len(W) if W else 0,
        'median_margin':med(margins), 'q90_margin':q(margins,0.9),
        'median_L':med(Ls), 'median_R_finite':med(Rs),
        'finite_R_frac':sum(1 for r in reg if finite(r['R']))/len(reg) if reg else 0,
        'inf_R_frac':sum(1 for r in reg if math.isinf(r['R']))/len(reg) if reg else 0,
        'right_H1_frac':rb.get(1,0)/len(reg) if reg else 0,
        'left_H0_or_empty_frac':(lb.get(-1,0)+lb.get(0,0))/len(reg) if reg else 0,
    }, rows

# ---------- experiment driver ----------

def nearest_centroid_accuracy(df, features):
    X = df[features].to_numpy(dtype=float)
    y = df["family"].to_numpy()
    mu = X.mean(axis=0)
    sd = X.std(axis=0)
    sd[sd == 0] = 1.0
    Z = (X - mu) / sd
    pred = []
    for i in range(len(y)):
        centroids = {}
        for fam in sorted(set(y)):
            inds = [j for j in range(len(y)) if j != i and y[j] == fam]
            centroids[fam] = Z[inds].mean(axis=0)
        dist = {fam: np.linalg.norm(Z[i] - c) for fam, c in centroids.items()}
        pred.append(min(dist, key=dist.get))
    pred = np.array(pred)
    return float((pred == y).mean()), pred


def run_experiment(out_dir, num_seeds=20, p=2, make_plots=True):
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    generators = [
        ("clique_rich", lambda s: gen_clique_rich(s)),
        ("cycle_rich", lambda s: gen_cycle_rich(s)),
        ("sparse_random", lambda s: gen_sparse_random(s)),
    ]

    summaries = []
    for family, gen in generators:
        for seed in range(num_seeds):
            n, W = gen(1000 + seed)
            summary, _ = summarize_graph(family, seed, n, W, p=p)
            summaries.append(summary)

    df = pd.DataFrame(summaries)
    df.to_csv(os.path.join(out_dir, "rsd_family_summaries.csv"), index=False)

    agg = df.groupby("family").agg(
        edges_mean=("m", "mean"),
        edges_std=("m", "std"),
        regular_frac_mean=("regular_frac", "mean"),
        regular_frac_std=("regular_frac", "std"),
        median_margin_mean=("median_margin", "mean"),
        median_margin_std=("median_margin", "std"),
        q90_margin_mean=("q90_margin", "mean"),
        q90_margin_std=("q90_margin", "std"),
        finite_R_frac_mean=("finite_R_frac", "mean"),
        finite_R_frac_std=("finite_R_frac", "std"),
        right_H1_frac_mean=("right_H1_frac", "mean"),
        right_H1_frac_std=("right_H1_frac", "std"),
        inf_R_frac_mean=("inf_R_frac", "mean"),
        inf_R_frac_std=("inf_R_frac", "std"),
    ).reset_index()
    agg.round(4).to_csv(os.path.join(out_dir, "rsd_family_aggregate.csv"), index=False)

    feature_sets = [
        ("all_five", ["regular_frac", "median_margin", "finite_R_frac", "right_H1_frac", "inf_R_frac"]),
        ("regular_plus_right_H1", ["regular_frac", "right_H1_frac"]),
        ("finite_R_plus_right_H1", ["finite_R_frac", "right_H1_frac"]),
        ("regular_only", ["regular_frac"]),
        ("right_H1_only", ["right_H1_frac"]),
        ("median_margin_only", ["median_margin"]),
    ]
    rows = []
    all_pred = None
    for name, features in feature_sets:
        acc, pred = nearest_centroid_accuracy(df, features)
        rows.append({"feature_set": name, "features": ";".join(features), "accuracy": acc,
                     "correct": int(round(acc * len(df))), "total": len(df)})
        if name == "all_five":
            all_pred = pred
    pd.DataFrame(rows).to_csv(os.path.join(out_dir, "rsd_feature_set_accuracy.csv"), index=False)

    conf = pd.crosstab(pd.Series(df["family"].to_numpy(), name="true"),
                       pd.Series(all_pred, name="pred"))
    conf.to_csv(os.path.join(out_dir, "rsd_classification_confusion.csv"))

    if make_plots:
        for col, fname, ylabel in [
            ("regular_frac", "fig_regular_fraction.png", "fraction of regular edges"),
            ("median_margin", "fig_median_margin.png", "median RSD margin"),
            ("right_H1_frac", "fig_h1_right_blocker.png", "fraction with right H1 blocker"),
        ]:
            plt.figure(figsize=(6, 4))
            groups = [df[df.family == fam][col].values for fam in ["clique_rich", "cycle_rich", "sparse_random"]]
            try:
                plt.boxplot(groups, tick_labels=["clique", "cycle", "random"])
            except TypeError:
                plt.boxplot(groups, labels=["clique", "cycle", "random"])
            plt.ylabel(ylabel)
            plt.tight_layout()
            plt.savefig(os.path.join(out_dir, fname), dpi=200)
            plt.close()

    print("Wrote RSD structural descriptor outputs to", out_dir)
    print(agg.round(4).to_string(index=False))
    print(pd.DataFrame(rows).to_string(index=False))


def main():
    import argparse
    ap = argparse.ArgumentParser(description="Synthetic RSD structural-descriptor experiment.")
    ap.add_argument("--out-dir", default="results/rsd_structure", help="Output directory.")
    ap.add_argument("--num-seeds", type=int, default=20, help="Number of graphs per family.")
    ap.add_argument("--p", type=int, default=2, help="Lower-link regularity parameter.")
    ap.add_argument("--no-plots", action="store_true", help="Skip diagnostic plots.")
    args = ap.parse_args()
    run_experiment(args.out_dir, num_seeds=args.num_seeds, p=args.p, make_plots=not args.no_plots)


if __name__ == "__main__":
    main()
