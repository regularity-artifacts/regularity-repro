#!/usr/bin/env python3
from __future__ import annotations

import csv
import sys
from collections import defaultdict
from pathlib import Path


def fnum(x, default=0.0):
    if x is None or x == "":
        return default
    try:
        return float(x)
    except Exception:
        return default


def inum(x, default=0):
    if x is None or x == "":
        return default
    try:
        return int(float(x))
    except Exception:
        return default


def pct(a, b):
    return 100.0 * a / b if b else 0.0


def summarize_stress_csv(path: Path) -> dict:
    rows = list(csv.DictReader(path.open()))
    fam = defaultdict(lambda: {"cases":0, "initial":0, "dom":0, "hyb":0})
    S = {
        "cases": len(rows),
        "initial": 0,
        "dom": 0,
        "hyb": 0,
        "hom": 0,
        "dom_inside": 0,
        "ph_calls": 0,
        "ph_success": 0,
        "dom_sec": 0.0,
        "hyb_sec": 0.0,
        "verify_sec": 0.0,
        "ph_checked": False,
        "ph_ok": True,
        "family": fam,
    }
    for r in rows:
        S["initial"] += inum(r.get("initial_edges"))
        S["dom"] += inum(r.get("domination_removed"))
        S["hyb"] += inum(r.get("hybrid_removed"))
        S["hom"] += inum(r.get("hybrid_homology_removals"))
        S["dom_inside"] += inum(r.get("hybrid_domination_removals"))
        S["ph_calls"] += inum(r.get("hybrid_ph_calls"))
        S["ph_success"] += inum(r.get("hybrid_ph_success"))
        S["dom_sec"] += fnum(r.get("domination_seconds"))
        S["hyb_sec"] += fnum(r.get("hybrid_seconds"))
        S["verify_sec"] += fnum(r.get("verification_ph_seconds"))
        checked = str(r.get("ph_checked")).lower() == "true"
        S["ph_checked"] = S["ph_checked"] or checked
        S["ph_ok"] = S["ph_ok"] and (str(r.get("ph_ok")).lower() != "false")
        k = r.get("family", "unknown")
        fam[k]["cases"] += 1
        fam[k]["initial"] += inum(r.get("initial_edges"))
        fam[k]["dom"] += inum(r.get("domination_removed"))
        fam[k]["hyb"] += inum(r.get("hybrid_removed"))
    return S


def summarize_mode_csv(path: Path) -> dict:
    rows = list(csv.DictReader(path.open()))
    mode = defaultdict(lambda: {"cases":0, "initial":0, "removed":0, "seconds":0.0, "ph_seconds":0.0,
                                "b3_cols":0, "b3_xor":0, "rec_succ":0, "rec_time":0.0, "hom":0})
    for r in rows:
        m = r.get("mode", "unknown")
        T = mode[m]
        T["cases"] += 1
        T["initial"] += inum(r.get("initial_edges"))
        T["removed"] += inum(r.get("removed"))
        T["seconds"] += fnum(r.get("seconds"))
        T["ph_seconds"] += fnum(r.get("ph_seconds"))
        T["b3_cols"] += inum(r.get("boundary3_columns"))
        T["b3_xor"] += inum(r.get("boundary3_xor_ops"))
        T["rec_succ"] += inum(r.get("recursive_prefilter_success"))
        T["rec_time"] += fnum(r.get("recursive_prefilter_seconds"))
        T["hom"] += inum(r.get("homology_removals"))
    return dict(mode)


def main():
    base = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("paper_experiments")
    out = base / "summary_tables.md"
    lines = ["# Paper experiment summary\n"]

    for d in sorted([p for p in base.iterdir() if p.is_dir()]):
        stress = d / "cpp_stress_results.csv"
        mode = d / "k3_mode_comparison.csv"
        if stress.exists():
            S = summarize_stress_csv(stress)
            lines.append(f"## {d.name}\n")
            lines.append("| cases | initial | domination removed | hybrid removed | extra | domination % | hybrid % | hybrid sec | verified |")
            lines.append("|---:|---:|---:|---:|---:|---:|---:|---:|:---:|")
            lines.append(
                f"| {S['cases']} | {S['initial']} | {S['dom']} | {S['hyb']} | {S['hyb']-S['dom']} | "
                f"{pct(S['dom'], S['initial']):.2f}% | {pct(S['hyb'], S['initial']):.2f}% | "
                f"{S['hyb_sec']:.3f} | {'yes' if S['ph_checked'] and S['ph_ok'] else ('no' if not S['ph_checked'] else 'FAIL')} |"
            )
            lines.append("\nFamily-wise:\n")
            lines.append("| family | cases | domination % | hybrid % | extra % |")
            lines.append("|---|---:|---:|---:|---:|")
            for fam, F in sorted(S["family"].items()):
                lines.append(
                    f"| {fam} | {F['cases']} | {pct(F['dom'], F['initial']):.2f}% | "
                    f"{pct(F['hyb'], F['initial']):.2f}% | {pct(F['hyb']-F['dom'], F['initial']):.2f}% |"
                )
            lines.append("")

        if mode.exists():
            M = summarize_mode_csv(mode)
            lines.append(f"## {d.name}\n")
            lines.append("| mode | cases | removed % | homology removals | seconds | PH sec | ∂3 columns | ∂3 XOR ops | rec successes | rec sec |")
            lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
            for m, T in sorted(M.items()):
                lines.append(
                    f"| {m} | {T['cases']} | {pct(T['removed'], T['initial']):.2f}% | {T['hom']} | "
                    f"{T['seconds']:.3f} | {T['ph_seconds']:.3f} | {T['b3_cols']} | {T['b3_xor']} | "
                    f"{T['rec_succ']} | {T['rec_time']:.3f} |"
                )
            lines.append("")

    out.write_text("\n".join(lines) + "\n")
    print(out)


if __name__ == "__main__":
    main()
