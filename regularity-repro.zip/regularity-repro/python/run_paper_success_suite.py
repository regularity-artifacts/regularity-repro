#!/usr/bin/env python3
"""
Main-paper success suite for certified homological trimming.

The suite is deliberately organized around the reviewer-facing story, not around
internal oracle tuning.

Pipelines compared in the main paper:

    raw_ripser          : Ripser on the original sparse flag complex
    dom_trim            : domination-only trimming + Ripser
    hom_trim            : domination + homological lower-link trimming + Ripser

Notation: p is the maximum homological degree sent to Ripser / certified by the
trimming oracle.  The C++ binary is called with --max-global-dim p.

Main questions answered by the generated CSV files:

(A) Value added by homological tests:
    How many extra edges does hom_trim remove beyond dom_trim, and at what cost?

(B) Scaling with number of points n:
    Does hom_trim improve PH scaling as n grows?

(C) Scaling with homological degree p:
    Does the advantage increase for higher-dimensional PH?

(D) Sparsity envelope:
    In which average-degree regime is the method useful?

(E) High-p sparse success cases:
    Can hom_trim make higher-p computations feasible when raw Ripser is slow or
    times out?

Outputs are checkpointed and resumable.  CSV filenames are deliberately explicit:

    A_value_add_large_sparse_raw.csv
    A_value_add_large_sparse_summary.csv
    B_scaling_n_points_raw.csv
    B_scaling_n_points_summary.csv
    C_scaling_p_degree_raw.csv
    C_scaling_p_degree_summary.csv
    D_sparsity_envelope_raw.csv
    D_sparsity_envelope_summary.csv
    E_high_p_sparse_success_raw.csv
    E_high_p_sparse_success_summary.csv
    F_dense_limit_optional_raw.csv       (only with --include-dense-limit)
    ALL_paper_success_jobs.csv
    RUN_MANIFEST.json

Typical use:

    # sanity check, no Ripser needed
    python3 python/run_paper_success_suite.py --profile smoke --skip-ph \
      --out-dir paper_success_smoke

    # pilot run with Ripser
    python3 python/run_paper_success_suite.py --profile pilot \
      --out-dir paper_success_pilot --ph-timeout 600

    # main paper run
    python3 python/run_paper_success_suite.py --profile paper \
      --out-dir paper_success_outputs --ph-timeout 3600 --trim-timeout 3600

    # selected high-p long run
    python3 python/run_paper_success_suite.py --profile paper-long \
      --out-dir paper_success_long --ph-timeout 14400 --trim-timeout 14400
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import multiprocessing as mp
import os
import random
import resource
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from scipy import sparse
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "ht_trim"
Edge = Tuple[int, int, float]

PIPELINES = {
    "dom_trim": "domination",
    "hom_trim": "hybrid",
}

MAX_F_DIM = 8  # CSV has f_1,...,f_8; f_d is number of d-simplices.


# ---------------------------------------------------------------------------
# CSV schema
# ---------------------------------------------------------------------------

RAW_FIELDS = [
    "job_id", "experiment", "profile", "family", "n", "m", "avg_degree",
    "target_degree", "block_size", "ambient_dim", "p", "seed", "pipeline", "oracle",
    "status", "trim_status", "ph_status", "trim_seconds", "ph_seconds", "total_seconds",
    "raw_ph_seconds", "speedup_vs_raw_total", "speedup_vs_raw_ph_only",
    "incremental_speedup_hom_vs_dom", "initial_edges", "final_edges", "removed_edges",
    "removed_pct", "extra_removed_edges_vs_dom", "extra_removed_pct_vs_dom", "delayed_count",
    "homology_removals", "domination_removals", "barcode_hash", "barcode_counts",
    "ph_match_raw", "peak_rss_mb_ph", "notes",
]
for d in range(1, MAX_F_DIM + 1):
    RAW_FIELDS.append(f"input_f_{d}")
for d in range(1, MAX_F_DIM + 1):
    RAW_FIELDS.append(f"final_f_{d}")


# ---------------------------------------------------------------------------
# Data generation
# ---------------------------------------------------------------------------

def _dedup_edges(edges: Iterable[Edge]) -> List[Edge]:
    best: Dict[Tuple[int, int], float] = {}
    for u, v, w in edges:
        if u == v:
            continue
        if u > v:
            u, v = v, u
        key = (int(u), int(v))
        fw = float(w)
        old = best.get(key)
        if old is None or fw < old:
            best[key] = fw
    return [(u, v, w) for (u, v), w in sorted(best.items())]


def geometric_knn(n: int, seed: int, target_degree: int, ambient_dim: int = 2, clustered: bool = False) -> List[Edge]:
    """Scalable sparse Euclidean kNN graph with symmetric edges."""
    rng = np.random.default_rng(seed)
    if clustered:
        kcenters = max(4, min(12, int(round(math.sqrt(n / 2000.0))) + 4))
        centers = rng.uniform(-1.0, 1.0, size=(kcenters, ambient_dim))
        labels = rng.integers(0, kcenters, size=n)
        pts = centers[labels] + 0.08 * rng.standard_normal((n, ambient_dim))
    else:
        pts = rng.random((n, ambient_dim))
    k = max(1, int(target_degree))
    tree = cKDTree(pts)
    # Query k+1 because the nearest neighbor is the point itself.
    dist, ind = tree.query(pts, k=min(k + 1, n), workers=-1)
    if ind.ndim == 1:
        ind = ind[:, None]
        dist = dist[:, None]
    edges = []
    for i in range(n):
        for jj, dd in zip(ind[i], dist[i]):
            j = int(jj)
            if i != j:
                edges.append((i, j, float(dd)))
    return _dedup_edges(edges)


def sparse_matrix_graph(n: int, seed: int, target_degree: int, ties: bool = False) -> List[Edge]:
    """Clique-rich sparse unstructured weighted graph.

    A plain Erdos--Renyi graph with average degree 12--32 is often locally
    tree-like; then both domination and homological trimming have little to do.
    For the main paper we want an unstructured *matrix-like* sparse filtration
    with nontrivial local flag structure.

    This generator therefore plants many small random cliques with generic
    weights and then tops up to the requested edge count with random edges.
    It is globally sparse, has no geometry or block ordering, but has enough
    triangles/tetrahedra for the homological lower-link tests to become visible.
    """
    rng = np.random.default_rng(seed)
    target_m = int(round(n * target_degree / 2.0))
    seen: set[Tuple[int, int]] = set()
    edges: List[Edge] = []

    def add_edge(u: int, v: int, w: float) -> None:
        if u == v:
            return
        if u > v:
            u, v = v, u
        key = (u, v)
        if key in seen:
            return
        seen.add(key)
        edges.append((u, v, float(round(w, 3) if ties else w)))

    # Small overlapping cliques create local flag complexity while preserving
    # global sparsity.  The size range grows mildly with target_degree.
    min_c = 4
    max_c = max(min_c + 1, min(10, int(round(math.sqrt(max(target_degree, 1)))) + 4))
    clique_budget = int(0.82 * target_m)
    attempts = 0
    max_attempts = max(1000, 20 * target_m)
    while len(edges) < clique_budget and attempts < max_attempts:
        attempts += 1
        c = int(rng.integers(min_c, max_c + 1))
        if c >= n:
            c = n
        verts = rng.choice(n, size=c, replace=False)
        # A local offset creates mild filtration coherence within a planted clique
        # without imposing a geometric model.
        offset = float(rng.random())
        scale = 0.25 + 0.75 * float(rng.random())
        before = len(edges)
        for i in range(c):
            for j in range(i + 1, c):
                w = 0.75 * float(rng.random()) + 0.25 * ((offset + scale * float(rng.random())) % 1.0)
                add_edge(int(verts[i]), int(verts[j]), w)
                if len(edges) >= clique_budget:
                    break
            if len(edges) >= clique_budget:
                break
        # If this clique mostly duplicated existing edges, move on; top-up below
        # guarantees the requested edge count.
        if len(edges) == before and attempts > max_attempts // 2:
            break

    # Top up with unrelated random weighted edges so the graph is not merely a
    # disjoint union of planted cliques.
    batch = max(10000, min(1000000, target_m // 2 + 1))
    while len(edges) < target_m:
        us = rng.integers(0, n, size=batch)
        vs = rng.integers(0, n, size=batch)
        ws = rng.random(batch)
        for u0, v0, w0 in zip(us, vs, ws):
            add_edge(int(u0), int(v0), float(w0))
            if len(edges) >= target_m:
                break
    edges.sort()
    return edges


def block_clique_graph(n: int, seed: int, block_size: int, ties: bool = False) -> List[Edge]:
    """Globally sparse, locally clique-rich stress graph."""
    rng = np.random.default_rng(seed)
    b = max(2, int(block_size))
    edges: List[Edge] = []
    for start in range(0, n, b):
        end = min(n, start + b)
        for i in range(start, end):
            for j in range(i + 1, end):
                w = float(rng.random())
                if ties:
                    w = round(w, 3)
                edges.append((i, j, w))
    return edges


def make_graph(family: str, n: int, seed: int, target_degree: int, block_size: int, ambient_dim: int) -> List[Edge]:
    if family == "geom_knn2":
        return geometric_knn(n, seed, target_degree, 2, clustered=False)
    if family == "geom_knn3":
        return geometric_knn(n, seed, target_degree, 3, clustered=False)
    if family == "geom_knn5":
        return geometric_knn(n, seed, target_degree, 5, clustered=False)
    if family == "cluster_knn2":
        return geometric_knn(n, seed, target_degree, 2, clustered=True)
    if family == "cluster_knn3":
        return geometric_knn(n, seed, target_degree, 3, clustered=True)
    if family == "sparse_matrix":
        return sparse_matrix_graph(n, seed, target_degree, ties=False)
    if family == "sparse_matrix_ties":
        return sparse_matrix_graph(n, seed, target_degree, ties=True)
    if family == "block_clique":
        return block_clique_graph(n, seed, block_size, ties=False)
    if family == "block_clique_ties":
        return block_clique_graph(n, seed, block_size, ties=True)
    raise ValueError(f"unknown family {family}")


# ---------------------------------------------------------------------------
# IO and command execution
# ---------------------------------------------------------------------------

def compile_cpp() -> None:
    subprocess.run(["make"], cwd=ROOT, check=True)


def write_edges(path: Path, edges: Sequence[Edge]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        for u, v, w in edges:
            if u > v:
                u, v = v, u
            f.write(f"{u} {v} {float(w):.17g}\n")


def read_edges(path: Path) -> List[Edge]:
    out: List[Edge] = []
    with path.open() as f:
        for line in f:
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            u, v, w = line.split()[:3]
            u, v = int(u), int(v)
            if u > v:
                u, v = v, u
            out.append((u, v, float(w)))
    out.sort()
    return out


def max_weight(edges: Sequence[Edge]) -> float:
    return max((float(w) for _, _, w in edges), default=0.0)


def run_trim(edge_path: Path, out_path: Path, report_path: Path, p: int, oracle: str, timeout: float) -> Dict:
    cmd = [
        str(BIN), str(edge_path), str(out_path),
        "--max-global-dim", str(p),
        "--oracle", oracle,
        "--schedule", "staged",
        "--order", "reverse",
        "--report", str(report_path),
        "--no-certificate",
    ]
    t0 = time.perf_counter()
    try:
        subprocess.run(cmd, cwd=ROOT, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=timeout)
    except subprocess.TimeoutExpired:
        return {"status": "timeout", "seconds": time.perf_counter() - t0, "stderr": "timeout"}
    except subprocess.CalledProcessError as e:
        return {"status": "trim_error", "seconds": time.perf_counter() - t0, "stderr": e.stderr.decode(errors="replace")[-4000:] if e.stderr else ""}
    seconds = time.perf_counter() - t0
    try:
        rep = json.loads(report_path.read_text())
    except Exception:
        rep = {}
    rep["status"] = "ok"
    rep["seconds_wall"] = seconds
    return rep


# ---------------------------------------------------------------------------
# Ripser in a killable subprocess
# ---------------------------------------------------------------------------

def _sparse_matrix_from_file(n: int, edge_path: str):
    rows: List[int] = []
    cols: List[int] = []
    vals: List[float] = []
    maxw = 0.0
    with open(edge_path) as f:
        for line in f:
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            u_s, v_s, w_s = line.split()[:3]
            u, v, w = int(u_s), int(v_s), float(w_s)
            if w <= 0.0:
                w = 1e-12
            rows.extend([u, v])
            cols.extend([v, u])
            vals.extend([w, w])
            if w > maxw:
                maxw = w
    D = sparse.coo_matrix((vals, (rows, cols)), shape=(n, n)).tocsr()
    return D, maxw


def _normalize_and_hash(dgms, p: int, threshold: float):
    h = hashlib.sha256()
    counts = []
    for dim in range(p + 1):
        bars = []
        if dim < len(dgms):
            for b, d in dgms[dim]:
                b = float(b)
                d = float(d)
                if b > threshold + 1e-7:
                    continue
                if not math.isinf(d) and d - b <= 1e-7:
                    continue
                bars.append((round(b, 7), None if math.isinf(d) else round(d, 7)))
        bars.sort(key=lambda x: (x[0], math.inf if x[1] is None else x[1]))
        counts.append(len(bars))
        h.update(f"dim={dim};count={len(bars)};".encode())
        for b, d in bars:
            h.update(f"{b:.7f},{'inf' if d is None else f'{d:.7f}'};".encode())
    return h.hexdigest(), counts


def _ph_worker(q: mp.Queue, n: int, edge_path: str, p: int):
    try:
        from ripser import ripser
        D, threshold = _sparse_matrix_from_file(n, edge_path)
        t0 = time.perf_counter()
        res = ripser(D, maxdim=p, distance_matrix=True, thresh=threshold)
        seconds = time.perf_counter() - t0
        digest, counts = _normalize_and_hash(res["dgms"], p, threshold)
        rss_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        # Linux reports KB; macOS reports bytes. This branch keeps values sane.
        rss_mb = rss_kb / 1024.0 if rss_kb < 10**9 else rss_kb / (1024.0 * 1024.0)
        q.put({"status": "ok", "seconds": seconds, "barcode_hash": digest, "barcode_counts": counts, "peak_rss_mb": rss_mb})
    except Exception as e:
        q.put({"status": f"ph_error:{type(e).__name__}", "seconds": "", "barcode_hash": "", "barcode_counts": [], "peak_rss_mb": "", "error": str(e)[:1000]})


def run_ph(n: int, edge_path: Path, p: int, timeout: float, skip_ph: bool) -> Dict:
    if skip_ph:
        return {"status": "skipped", "seconds": "", "barcode_hash": "", "barcode_counts": [], "peak_rss_mb": ""}
    q: mp.Queue = mp.Queue()
    proc = mp.Process(target=_ph_worker, args=(q, n, str(edge_path), p))
    proc.start()
    proc.join(timeout)
    if proc.is_alive():
        proc.terminate()
        proc.join(5)
        return {"status": "timeout", "seconds": timeout, "barcode_hash": "", "barcode_counts": [], "peak_rss_mb": ""}
    if not q.empty():
        return q.get()
    return {"status": "ph_error:no_result", "seconds": "", "barcode_hash": "", "barcode_counts": [], "peak_rss_mb": ""}


# ---------------------------------------------------------------------------
# Optional simplex counts
# ---------------------------------------------------------------------------

def _comb(n: int, r: int) -> int:
    if r < 0 or r > n:
        return 0
    return math.comb(n, r)


def block_raw_f_counts(n: int, block_size: int, max_f_dim: int) -> Dict[int, int]:
    out = {d: 0 for d in range(1, MAX_F_DIM + 1)}
    b = max(2, int(block_size))
    for start in range(0, n, b):
        s = min(b, n - start)
        for d in range(1, min(max_f_dim, MAX_F_DIM) + 1):
            out[d] += _comb(s, d + 1)
    return out


def exact_clique_counts(n: int, edges: Sequence[Edge], max_f_dim: int, max_edges: int = 300000) -> Optional[Dict[int, int]]:
    """Exact f_1,... counts for small/medium sparse graphs; skips huge cases."""
    if len(edges) > max_edges:
        return None
    max_f_dim = min(max_f_dim, MAX_F_DIM)
    adj = [set() for _ in range(n)]
    for u, v, _ in edges:
        adj[u].add(v)
        adj[v].add(u)
    counts = {d: 0 for d in range(1, MAX_F_DIM + 1)}
    counts[1] = len(edges)
    if max_f_dim <= 1:
        return counts
    forward = [sorted(v for v in adj[u] if v > u) for u in range(n)]

    def extend(candidates: List[int], current_size: int):
        for i, v in enumerate(candidates):
            next_size = current_size + 1
            d = next_size - 1
            # counts[1] was initialized as the undirected edge count.  Do not
            # count edges again here; only count triangles and higher cliques.
            if 2 <= d <= max_f_dim:
                counts[d] += 1
            if d < max_f_dim:
                av = adj[v]
                new_cands = [w for w in candidates[i + 1:] if w in av]
                if new_cands:
                    extend(new_cands, next_size)

    for u in range(n):
        if forward[u]:
            extend(forward[u], 1)
    return counts


def f_counts_for_case(family: str, n: int, block_size: int, edges: Sequence[Edge], max_f_dim: int, mode: str, count_simplices: str) -> Dict[int, str | int]:
    out: Dict[int, str | int] = {d: "" for d in range(1, MAX_F_DIM + 1)}
    out[1] = len(edges)
    if count_simplices == "off":
        return out
    if family.startswith("block_clique") and mode == "input":
        c = block_raw_f_counts(n, block_size, max_f_dim)
        out.update(c)
        return out
    if count_simplices == "auto" and len(edges) > 300000:
        return out
    c = exact_clique_counts(n, edges, max_f_dim)
    if c is not None:
        out.update(c)
    return out


# ---------------------------------------------------------------------------
# Job specifications and profiles
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class CaseSpec:
    experiment: str
    family: str
    n: int
    target_degree: int
    block_size: int
    ambient_dim: int
    p: int
    seed: int

    def key(self) -> str:
        return f"{self.experiment}|{self.family}|n{self.n}|deg{self.target_degree}|b{self.block_size}|dim{self.ambient_dim}|p{self.p}|s{self.seed}"


def profile_specs(args) -> List[CaseSpec]:
    seeds = args.seeds
    specs: List[CaseSpec] = []

    def add(exp: str, families: Sequence[str], ns: Sequence[int], ps: Sequence[int], degrees: Sequence[int], blocks: Sequence[int], seeds0: Sequence[int]):
        for fam in families:
            for n in ns:
                for p in ps:
                    for seed in seeds0:
                        if fam.startswith("block_clique"):
                            for b in blocks:
                                specs.append(CaseSpec(exp, fam, n, 0, b, 0, p, seed))
                        else:
                            for deg in degrees:
                                dim = 2 if fam.endswith("2") else (3 if fam.endswith("3") else (5 if fam.endswith("5") else 0))
                                specs.append(CaseSpec(exp, fam, n, deg, 0, dim, p, seed))

    if args.profile == "smoke":
        add("A_value_add_large_sparse", ["geom_knn2", "sparse_matrix", "block_clique"], [300], [1, 2], [12], [12], [1])
        add("B_scaling_n_points", ["geom_knn2", "sparse_matrix"], [300, 600], [1, 2], [12], [], [1])
        add("C_scaling_p_degree", ["block_clique"], [600], [1, 2, 3], [], [12], [1])
        add("D_sparsity_envelope", ["geom_knn2", "sparse_matrix"], [600], [2], [8, 16], [], [1])
        add("E_high_p_sparse_success", ["block_clique"], [1000], [2, 3], [], [12], [1])
        return specs

    if args.profile == "pilot":
        add("A_value_add_large_sparse", ["geom_knn2", "geom_knn3", "sparse_matrix", "block_clique"], [2000, 5000], [1, 2, 3], [16, 24], [16, 24], seeds[:2])
        add("B_scaling_n_points", ["geom_knn2", "geom_knn3", "sparse_matrix"], [2000, 5000, 10000], [2, 3], [24], [], seeds[:2])
        add("C_scaling_p_degree", ["block_clique", "sparse_matrix"], [5000], [1, 2, 3, 4], [24], [16, 24], seeds[:2])
        add("D_sparsity_envelope", ["geom_knn3", "sparse_matrix"], [5000], [2, 3], [8, 12, 24, 48], [], seeds[:2])
        add("E_high_p_sparse_success", ["block_clique"], [10000], [3, 4, 5], [], [16, 24, 32], seeds[:2])
        return specs

    if args.profile == "paper":
        add("A_value_add_large_sparse", ["geom_knn2", "geom_knn3", "cluster_knn2", "sparse_matrix", "sparse_matrix_ties", "block_clique"], [5000, 10000], [1, 2, 3, 4], [24, 32], [16, 24, 32], seeds)
        add("B_scaling_n_points", ["geom_knn2", "geom_knn3", "sparse_matrix"], [5000, 10000, 20000, 50000], [2, 3, 4], [24], [], seeds)
        add("C_scaling_p_degree", ["block_clique", "sparse_matrix"], [10000], [1, 2, 3, 4, 5, 6, 7], [24, 32], [16, 24, 32], seeds)
        add("D_sparsity_envelope", ["geom_knn3", "sparse_matrix"], [10000], [2, 3, 4], [8, 12, 16, 24, 32, 48, 64], [], seeds)
        add("E_high_p_sparse_success", ["block_clique"], [25000, 50000], [3, 4, 5, 6, 7], [], [16, 24, 32], seeds)
        return specs

    if args.profile == "paper-long":
        add("E_high_p_sparse_success", ["block_clique"], [50000, 100000], [4, 5, 6, 7], [], [16, 24, 32, 48], seeds)
        add("B_scaling_n_points", ["geom_knn3", "sparse_matrix"], [50000, 100000], [3, 4, 5], [24, 32], [], seeds)
        return specs

    raise ValueError(args.profile)


def maybe_add_dense_limit(specs: List[CaseSpec], args) -> None:
    if not args.include_dense_limit:
        return
    # Intentionally small: this is a limitation/appendix experiment, not the success story.
    for n in [80, 120, 160]:
        for p in [1, 2, 3]:
            for seed in args.seeds[:2]:
                specs.append(CaseSpec("F_dense_limit_optional", "block_clique", n, 0, n, 0, p, seed))


# ---------------------------------------------------------------------------
# CSV/checkpoint helpers
# ---------------------------------------------------------------------------

def output_name(experiment: str, kind: str) -> str:
    return f"{experiment}_{kind}.csv"


def append_rows(path: Path, rows: Sequence[Dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists()
    with path.open("a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=RAW_FIELDS)
        if not exists:
            w.writeheader()
        for r in rows:
            clean = {k: r.get(k, "") for k in RAW_FIELDS}
            w.writerow(clean)


def load_done_jobs(out_dir: Path, resume: bool) -> set[str]:
    if not resume:
        return set()
    done = set()
    all_path = out_dir / "ALL_paper_success_jobs.csv"
    if all_path.exists():
        with all_path.open() as f:
            for row in csv.DictReader(f):
                if row.get("status") in {"ok", "ph_timeout", "trim_timeout", "trim_error", "ph_error", "skipped_ph"}:
                    done.add(row.get("job_id", ""))
    return done


def finite_float(x) -> Optional[float]:
    try:
        if x == "" or x is None:
            return None
        y = float(x)
        if math.isnan(y) or math.isinf(y):
            return None
        return y
    except Exception:
        return None


def summarize_experiment(raw_path: Path, summary_path: Path) -> None:
    try:
        import pandas as pd
    except Exception:
        return
    if not raw_path.exists():
        return
    df = pd.read_csv(raw_path)
    if df.empty:
        return
    for c in ["n", "m", "avg_degree", "target_degree", "block_size", "p", "trim_seconds", "ph_seconds", "total_seconds", "raw_ph_seconds", "speedup_vs_raw_total", "incremental_speedup_hom_vs_dom", "removed_pct", "extra_removed_pct_vs_dom", "final_edges", "removed_edges"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    group_cols = ["experiment", "family", "n", "target_degree", "block_size", "p", "pipeline"]
    agg = df.groupby(group_cols, dropna=False).agg(
        cases=("job_id", "count"),
        ok_cases=("status", lambda s: int(s.isin(["ok", "skipped_ph"]).sum())),
        ph_ok_cases=("ph_status", lambda s: int((s == "ok").sum())),
        trim_ok_cases=("trim_status", lambda s: int((s == "ok").sum())),
        mean_m=("m", "mean"),
        mean_avg_degree=("avg_degree", "mean"),
        mean_removed_pct=("removed_pct", "mean"),
        mean_extra_removed_pct_vs_dom=("extra_removed_pct_vs_dom", "mean"),
        mean_trim_seconds=("trim_seconds", "mean"),
        mean_ph_seconds=("ph_seconds", "mean"),
        mean_total_seconds=("total_seconds", "mean"),
        mean_raw_ph_seconds=("raw_ph_seconds", "mean"),
        mean_speedup_vs_raw_total=("speedup_vs_raw_total", "mean"),
        mean_incremental_speedup_hom_vs_dom=("incremental_speedup_hom_vs_dom", "mean"),
        ph_timeouts=("ph_status", lambda s: int((s == "timeout").sum())),
        trim_timeouts=("trim_status", lambda s: int((s == "timeout").sum())),
        ph_match_raw_all=("ph_match_raw", lambda s: all(str(x) in {"True", "true", "1", "", "nan"} for x in s)),
    ).reset_index()
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    agg.to_csv(summary_path, index=False)


# ---------------------------------------------------------------------------
# Running one case
# ---------------------------------------------------------------------------

def base_row(spec: CaseSpec, pipeline: str, oracle: str, edges: Sequence[Edge]) -> Dict:
    m = len(edges)
    return {
        "job_id": f"{spec.key()}|{pipeline}",
        "experiment": spec.experiment,
        "profile": "",
        "family": spec.family,
        "n": spec.n,
        "m": m,
        "avg_degree": round(2.0 * m / spec.n, 6) if spec.n else 0.0,
        "target_degree": spec.target_degree,
        "block_size": spec.block_size,
        "ambient_dim": spec.ambient_dim,
        "p": spec.p,
        "seed": spec.seed,
        "pipeline": pipeline,
        "oracle": oracle,
        "initial_edges": m,
    }


def fill_f_counts(row: Dict, prefix: str, counts: Dict[int, str | int]) -> None:
    for d in range(1, MAX_F_DIM + 1):
        row[f"{prefix}_f_{d}"] = counts.get(d, "")


def run_case(spec: CaseSpec, args, work_dir: Path) -> List[Dict]:
    case_dir = work_dir / spec.experiment / f"{spec.family}_n{spec.n}_deg{spec.target_degree}_b{spec.block_size}_p{spec.p}_s{spec.seed}"
    case_dir.mkdir(parents=True, exist_ok=True)
    input_path = case_dir / "input_edges.txt"

    t_gen0 = time.perf_counter()
    edges = make_graph(spec.family, spec.n, spec.seed, spec.target_degree, spec.block_size, spec.ambient_dim)
    gen_seconds = time.perf_counter() - t_gen0
    write_edges(input_path, edges)

    max_f_dim = min(spec.p + 1, MAX_F_DIM)
    input_counts = f_counts_for_case(spec.family, spec.n, spec.block_size, edges, max_f_dim, "input", args.count_simplices)

    rows: List[Dict] = []

    # Raw Ripser.
    raw_ph = run_ph(spec.n, input_path, spec.p, args.ph_timeout, args.skip_ph)
    raw_row = base_row(spec, "raw_ripser", "", edges)
    raw_row["profile"] = args.profile
    raw_row.update({
        "status": "ok" if raw_ph["status"] == "ok" else ("skipped_ph" if raw_ph["status"] == "skipped" else "ph_timeout" if raw_ph["status"] == "timeout" else "ph_error"),
        "trim_status": "",
        "ph_status": raw_ph["status"],
        "trim_seconds": 0.0,
        "ph_seconds": raw_ph.get("seconds", ""),
        "total_seconds": raw_ph.get("seconds", "") if raw_ph["status"] == "ok" else "",
        "raw_ph_seconds": raw_ph.get("seconds", "") if raw_ph["status"] == "ok" else "",
        "final_edges": len(edges),
        "removed_edges": 0,
        "removed_pct": 0.0,
        "barcode_hash": raw_ph.get("barcode_hash", ""),
        "barcode_counts": json.dumps(raw_ph.get("barcode_counts", [])),
        "peak_rss_mb_ph": raw_ph.get("peak_rss_mb", ""),
        "notes": f"generation_seconds={gen_seconds:.6f}",
    })
    fill_f_counts(raw_row, "input", input_counts)
    fill_f_counts(raw_row, "final", input_counts)
    rows.append(raw_row)

    raw_total = finite_float(raw_row.get("total_seconds"))
    raw_hash = raw_ph.get("barcode_hash", "") if raw_ph.get("status") == "ok" else ""

    pipeline_results: Dict[str, Dict] = {}
    for pipeline, oracle in PIPELINES.items():
        out_path = case_dir / f"{pipeline}_edges.txt"
        rep_path = case_dir / f"{pipeline}_report.json"
        rep = run_trim(input_path, out_path, rep_path, spec.p, oracle, args.trim_timeout)
        row = base_row(spec, pipeline, oracle, edges)
        row["profile"] = args.profile
        fill_f_counts(row, "input", input_counts)
        if rep.get("status") != "ok":
            row.update({
                "status": "trim_timeout" if rep.get("status") == "timeout" else "trim_error",
                "trim_status": rep.get("status"),
                "ph_status": "",
                "trim_seconds": round(float(rep.get("seconds", 0.0)), 6),
                "notes": rep.get("stderr", ""),
            })
            rows.append(row)
            pipeline_results[pipeline] = row
            continue

        reduced = read_edges(out_path)
        final_counts = f_counts_for_case(spec.family, spec.n, spec.block_size, reduced, max_f_dim, "final", args.count_simplices)
        ph_after = run_ph(spec.n, out_path, spec.p, args.ph_timeout, args.skip_ph)
        trim_seconds = float(rep.get("seconds", rep.get("seconds_wall", 0.0)))
        ph_seconds = finite_float(ph_after.get("seconds"))
        total_seconds = trim_seconds + ph_seconds if ph_seconds is not None else ""
        removed_edges = len(edges) - len(reduced)
        removed_pct = 100.0 * removed_edges / len(edges) if edges else 0.0
        ph_match = ""
        if raw_hash and ph_after.get("status") == "ok":
            ph_match = (raw_hash == ph_after.get("barcode_hash", ""))
        status = "ok"
        if ph_after["status"] == "skipped":
            status = "skipped_ph"
        elif ph_after["status"] == "timeout":
            status = "ph_timeout"
        elif ph_after["status"] != "ok":
            status = "ph_error"

        row.update({
            "status": status,
            "trim_status": "ok",
            "ph_status": ph_after["status"],
            "trim_seconds": round(trim_seconds, 6),
            "ph_seconds": "" if ph_seconds is None else round(ph_seconds, 6),
            "total_seconds": "" if total_seconds == "" else round(float(total_seconds), 6),
            "raw_ph_seconds": "" if raw_total is None else round(raw_total, 6),
            "speedup_vs_raw_total": "" if raw_total is None or total_seconds == "" or float(total_seconds) <= 0 else round(raw_total / float(total_seconds), 6),
            "speedup_vs_raw_ph_only": "" if raw_total is None or ph_seconds is None or ph_seconds <= 0 else round(raw_total / ph_seconds, 6),
            "final_edges": len(reduced),
            "removed_edges": removed_edges,
            "removed_pct": round(removed_pct, 6),
            "delayed_count": int(rep.get("delayed_count", 0)),
            "homology_removals": int(rep.get("homology_removals", 0)),
            "domination_removals": int(rep.get("domination_removals", 0)),
            "barcode_hash": ph_after.get("barcode_hash", ""),
            "barcode_counts": json.dumps(ph_after.get("barcode_counts", [])),
            "ph_match_raw": ph_match,
            "peak_rss_mb_ph": ph_after.get("peak_rss_mb", ""),
            "notes": f"generation_seconds={gen_seconds:.6f}",
        })
        fill_f_counts(row, "final", final_counts)
        rows.append(row)
        pipeline_results[pipeline] = row

    # Incremental homology-over-domination quantities.
    dom = pipeline_results.get("dom_trim")
    hom = pipeline_results.get("hom_trim")
    if dom and hom:
        dom_removed = finite_float(dom.get("removed_edges"))
        hom_removed = finite_float(hom.get("removed_edges"))
        dom_removed_pct = finite_float(dom.get("removed_pct"))
        hom_removed_pct = finite_float(hom.get("removed_pct"))
        dom_total = finite_float(dom.get("total_seconds"))
        hom_total = finite_float(hom.get("total_seconds"))
        for r in rows:
            if r.get("pipeline") == "hom_trim":
                if dom_removed is not None and hom_removed is not None:
                    r["extra_removed_edges_vs_dom"] = int(hom_removed - dom_removed)
                if dom_removed_pct is not None and hom_removed_pct is not None:
                    r["extra_removed_pct_vs_dom"] = round(hom_removed_pct - dom_removed_pct, 6)
                if dom_total is not None and hom_total is not None and hom_total > 0:
                    r["incremental_speedup_hom_vs_dom"] = round(dom_total / hom_total, 6)

    if not args.keep_work_files:
        # Keep only compact C++ reports, not huge edge files.
        for fp in case_dir.glob("*_edges.txt"):
            try:
                fp.unlink()
            except Exception:
                pass
        try:
            input_path.unlink()
        except Exception:
            pass
    return rows


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def run_suite(args) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    work_dir = out_dir / "_work"
    work_dir.mkdir(parents=True, exist_ok=True)
    compile_cpp()

    specs = profile_specs(args)
    maybe_add_dense_limit(specs, args)
    done = load_done_jobs(out_dir, args.resume)

    manifest = {
        "profile": args.profile,
        "seeds": args.seeds,
        "skip_ph": args.skip_ph,
        "ph_timeout": args.ph_timeout,
        "trim_timeout": args.trim_timeout,
        "count_simplices": args.count_simplices,
        "num_cases": len(specs),
        "pipelines": ["raw_ripser", "dom_trim", "hom_trim"],
        "notation": "p denotes maximum homological degree.",
        "csv_files": sorted({output_name(s.experiment, "raw") for s in specs}),
        "created_at_unix": time.time(),
    }
    (out_dir / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")

    for idx, spec in enumerate(specs, start=1):
        job_ids = [f"{spec.key()}|raw_ripser", f"{spec.key()}|dom_trim", f"{spec.key()}|hom_trim"]
        if args.resume and all(j in done for j in job_ids):
            print(f"[{idx}/{len(specs)}] skip existing {spec.key()}", flush=True)
            continue
        print(f"[{idx}/{len(specs)}] {spec.experiment} {spec.family} n={spec.n} deg={spec.target_degree} b={spec.block_size} p={spec.p} seed={spec.seed}", flush=True)
        rows = run_case(spec, args, work_dir)
        exp_raw = out_dir / output_name(spec.experiment, "raw")
        append_rows(exp_raw, rows)
        append_rows(out_dir / "ALL_paper_success_jobs.csv", rows)
        for r in rows:
            done.add(r["job_id"])

    # Summaries.
    experiments = sorted({s.experiment for s in specs})
    for exp in experiments:
        summarize_experiment(out_dir / output_name(exp, "raw"), out_dir / output_name(exp, "summary"))
    summarize_experiment(out_dir / "ALL_paper_success_jobs.csv", out_dir / "ALL_paper_success_summary.csv")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--profile", choices=["smoke", "pilot", "paper", "paper-long"], default="smoke")
    ap.add_argument("--out-dir", default="paper_success_outputs")
    ap.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3])
    ap.add_argument("--skip-ph", action="store_true", help="Skip Ripser timings; useful for a fast code-path check.")
    ap.add_argument("--ph-timeout", type=float, default=3600.0, help="Timeout in seconds for each Ripser call.")
    ap.add_argument("--trim-timeout", type=float, default=3600.0, help="Timeout in seconds for each trimming call.")
    ap.add_argument("--count-simplices", choices=["off", "auto", "always"], default="auto",
                    help="Count f_2,f_3,... exactly when feasible. auto skips non-block cases above 300k edges.")
    ap.add_argument("--include-dense-limit", action="store_true", help="Also run a small dense-limit/appendix experiment.")
    ap.add_argument("--resume", action="store_true", help="Resume from existing ALL_paper_success_jobs.csv.")
    ap.add_argument("--keep-work-files", action="store_true", help="Keep generated edge files. This can use substantial disk space.")
    args = ap.parse_args()
    run_suite(args)


if __name__ == "__main__":
    # Fork is substantially cheaper for large Python objects on Linux.  On macOS
    # this call may fail harmlessly after the context is set by the interpreter.
    try:
        mp.set_start_method("fork")
    except RuntimeError:
        pass
    main()
