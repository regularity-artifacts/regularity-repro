#!/usr/bin/env python3
"""Subprocess wrapper for the modular ht-trim C++ engine."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "ht_trim"


def build_engine(force: bool = False) -> Path:
    if BIN.exists() and not force:
        return BIN
    if shutil.which("make") is None:
        raise RuntimeError("make is required to build the engine")
    subprocess.run(["make"], cwd=ROOT, check=True)
    return BIN


def trim_edges(
    input_edges: str | Path,
    output_edges: str | Path,
    *,
    max_global_dim: int = 1,
    oracle: str = "hybrid",
    schedule: str = "staged",
    order: str = "reverse",
    k2_prefilter: str = "none",
    report: Optional[str | Path] = None,
    certificate: bool = True,
    build_first: bool = True,
) -> dict:
    if build_first:
        build_engine()
    input_edges = Path(input_edges)
    output_edges = Path(output_edges)
    if report is None:
        report = output_edges.with_suffix(".report.json")
    report = Path(report)
    cmd = [
        str(BIN), str(input_edges), str(output_edges),
        "--max-global-dim", str(max_global_dim),
        "--oracle", oracle,
        "--schedule", schedule,
        "--order", order,
        "--k2-prefilter", k2_prefilter,
        "--report", str(report),
    ]
    if not certificate:
        cmd.append("--no-certificate")
    subprocess.run(cmd, check=True)
    return json.loads(report.read_text())


__all__ = ["build_engine", "trim_edges"]
