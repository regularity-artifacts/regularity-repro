#include "ht/trim_engine.hpp"
#include <algorithm>

namespace ht {

LowerLink2& TrimEngine::build_lower_link_1_skeleton(EdgeId eid) const {
    auto const& e = G_.edge(eid);

    // Fetch common neighbors together with their alpha (=max(w(u,q),w(v,q)))
    // in a single merge-join pass over the sorted adjacency lists, instead of
    // computing the neighbor set and then looking each weight back up.
    std::vector<int> common;
    std::vector<double> alpha;
    G_.active_common_neighbors_with_alpha(e.u, e.v, common, alpha);

    LowerLink2& L = scratch_link_;
    L.clear();
    L.V.reserve(common.size());
    for (size_t i = 0; i < common.size(); ++i) {
        L.V.push_back({common[i], alpha[i]});
    }

    const int m = static_cast<int>(L.V.size());
    L.init_edge_lookup(m);
    for (int i = 0; i < m; ++i) {
        for (int j = i + 1; j < m; ++j) {
            double wij;
            if (!G_.active_weight(L.V[i].q, L.V[j].q, &wij)) continue;
            double beta = std::max({L.V[i].alpha, L.V[j].alpha, wij});
            int eid_local = static_cast<int>(L.E.size());
            L.E.push_back({i, j, beta});
            L.set_local_edge_id(i, j, eid_local);
        }
    }
    return L;
}

void TrimEngine::build_lower_link_triangles(LowerLink2& L) const {
    const int m = static_cast<int>(L.V.size());
    if (m < 3) return;
    L.init_triangle_lookup(m);
    for (int i = 0; i < m; ++i) {
        for (int j = i + 1; j < m; ++j) {
            int eij = L.local_edge_id(i, j);
            if (eij < 0) continue;
            for (int k = j + 1; k < m; ++k) {
                int eik = L.local_edge_id(i, k);
                if (eik < 0) continue;
                int ejk = L.local_edge_id(j, k);
                if (ejk < 0) continue;
                double gamma = std::max({L.E[eij].beta, L.E[eik].beta, L.E[ejk].beta});
                int tid = static_cast<int>(L.T.size());
                L.T.push_back({i, j, k, gamma});
                L.set_local_triangle_id(i, j, k, tid);
            }
        }
    }
}


void TrimEngine::build_lower_link_tetrahedra(LowerLink2& L) const {
    const int m = static_cast<int>(L.V.size());
    if (m < 4) return;
    if (L.triangle_id.empty()) {
        L.init_triangle_lookup(m);
        for (int tid = 0; tid < static_cast<int>(L.T.size()); ++tid) {
            auto const& t = L.T[tid];
            L.set_local_triangle_id(t.a, t.b, t.c, tid);
        }
    }

    for (int i = 0; i < m; ++i) {
        for (int j = i + 1; j < m; ++j) {
            if (L.local_edge_id(i, j) < 0) continue;
            for (int k = j + 1; k < m; ++k) {
                if (L.local_edge_id(i, k) < 0 || L.local_edge_id(j, k) < 0) continue;
                int tijk = L.local_triangle_id(i, j, k);
                if (tijk < 0) continue;
                for (int l = k + 1; l < m; ++l) {
                    if (L.local_edge_id(i, l) < 0 || L.local_edge_id(j, l) < 0 || L.local_edge_id(k, l) < 0) continue;
                    int tijl = L.local_triangle_id(i, j, l);
                    int tikl = L.local_triangle_id(i, k, l);
                    int tjkl = L.local_triangle_id(j, k, l);
                    if (tijl < 0 || tikl < 0 || tjkl < 0) continue;
                    double delta = std::max({L.T[tijk].gamma, L.T[tijl].gamma, L.T[tikl].gamma, L.T[tjkl].gamma});
                    L.Q.push_back({i, j, k, l, delta});
                }
            }
        }
    }
}

LowerLink2& TrimEngine::build_local_edge_lower_link_1_skeleton(LowerLink2 const& L,
                                                                std::vector<char> const& active_edge,
                                                                int local_eid) const {
    LowerLink2& A = scratch_local_edge_link_;
    A.clear();
    if (local_eid < 0 || local_eid >= static_cast<int>(L.E.size()) || !active_edge[local_eid]) return A;

    auto const& base = L.E[local_eid];
    const int a = base.a;
    const int b = base.b;
    const int m = static_cast<int>(L.V.size());
    auto at = [m](int i, int j) { return i * m + j; };

    std::vector<int> common;
    std::vector<double> alpha;
    common.reserve(m);
    alpha.reserve(m);

    for (int q = 0; q < m; ++q) {
        if (q == a || q == b) continue;
        int eaq = L.edge_id[at(a, q)];
        int ebq = L.edge_id[at(b, q)];
        if (eaq < 0 || ebq < 0) continue;
        if (!active_edge[eaq] || !active_edge[ebq]) continue;
        common.push_back(q);
        alpha.push_back(std::max(L.E[eaq].beta, L.E[ebq].beta));
    }

    A.V.reserve(common.size());
    for (size_t i = 0; i < common.size(); ++i) A.V.push_back({common[i], alpha[i]});

    const int r = static_cast<int>(A.V.size());
    A.init_edge_lookup(r);
    for (int i = 0; i < r; ++i) {
        for (int j = i + 1; j < r; ++j) {
            int qi = common[i];
            int qj = common[j];
            int eqiqj = L.edge_id[at(qi, qj)];
            if (eqiqj < 0 || !active_edge[eqiqj]) continue;
            double beta = std::max({alpha[i], alpha[j], L.E[eqiqj].beta});
            int id = static_cast<int>(A.E.size());
            A.E.push_back({i, j, beta});
            A.set_local_edge_id(i, j, id);
        }
    }
    return A;
}

} // namespace ht
