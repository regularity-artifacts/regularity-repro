#include "ht/trim_engine.hpp"

#include <gudhi/Flag_complex_edge_collapser.h>

#include <tuple>
#include <unordered_map>
#include <vector>

namespace ht {

void TrimEngine::run_gudhi_collapse() {
    using FE = std::tuple<int, int, double>;
    std::vector<FE> input;
    input.reserve(static_cast<size_t>(G_.m()));
    std::unordered_map<uint64_t, double> original_weight;
    original_weight.reserve(static_cast<size_t>(G_.m()) * 2 + 1);
    for (auto const& e : G_.edges()) {
        if (!e.active) continue;
        input.emplace_back(e.u, e.v, e.w);
        original_weight[key_edge(e.u, e.v)] = e.w;
    }

    double t0 = now_seconds();
    auto output = Gudhi::collapse::flag_complex_collapse_edges(input);
    st_.domination_seconds += now_seconds() - t0;

    std::vector<Edge> edges;
    edges.reserve(output.size());
    int delayed = 0;
    double total_delay = 0.0;
    double max_delay = 0.0;
    for (auto const& e : output) {
        Edge x;
        x.u = std::get<0>(e);
        x.v = std::get<1>(e);
        x.w = std::get<2>(e);
        x.active = true;
        auto it = original_weight.find(key_edge(x.u, x.v));
        if (it != original_weight.end() && x.w > it->second + EPS) {
            ++delayed;
            total_delay += x.w - it->second;
            max_delay = std::max(max_delay, x.w - it->second);
        }
        edges.push_back(x);
    }
    st_.delayed_count += delayed;
    st_.total_delay += total_delay;
    st_.max_delay = std::max(st_.max_delay, max_delay);

    G_.build(edges);
    st_.domination_calls = static_cast<long long>(input.size());
    st_.domination_success = static_cast<long long>(input.size() >= output.size() ? input.size() - output.size() : 0);
    st_.domination_fail = static_cast<long long>(output.size());
    st_.domination_removals = static_cast<int>(input.size() >= output.size() ? input.size() - output.size() : 0);
}

} // namespace ht
