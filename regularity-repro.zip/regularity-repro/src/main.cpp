#include "ht/graph.hpp"
#include "ht/io.hpp"
#include "ht/options.hpp"
#include "ht/trim_engine.hpp"

#include <exception>
#include <iostream>
#include <string>
#include <utility>

int main(int argc, char** argv) {
    try {
        if (argc < 3) { ht::usage(); return 1; }
        std::string input = argv[1];
        std::string output = argv[2];
        std::string report;
        ht::Options opt;

        for (int i = 3; i < argc; ++i) {
            std::string a = argv[i];
            auto val = [&](const std::string& flag) {
                if (i + 1 >= argc) throw std::runtime_error("missing value after " + flag);
                return std::string(argv[++i]);
            };
            if (a == "--max-global-dim") opt.max_global_dim = std::stoi(val(a));
            else if (a == "--oracle") opt.oracle = ht::parse_oracle(val(a));
            else if (a == "--schedule") opt.schedule = ht::parse_schedule(val(a));
            else if (a == "--order") opt.order = ht::parse_order(val(a));
            else if (a == "--k2-prefilter") opt.k2_prefilter = ht::parse_k2_prefilter(val(a));
            else if (a == "--k3-mode") opt.k3_mode = ht::parse_k3_mode(val(a));
            else if (a == "--report") report = val(a);
            else if (a == "--no-certificate") opt.certificate = false;
            else if (a == "--force-general") opt.force_general = true;
            else if (a == "--help" || a == "-h") { ht::usage(); return 0; }
            else throw std::runtime_error("unknown argument " + a);
        }

        ht::WeightedGraph G(ht::read_edges(input));
        ht::TrimEngine engine(std::move(G), opt);
        auto stats = engine.run();
        engine.graph().write_active_edges(output);
        if (!report.empty()) ht::write_report(report, opt, stats);

        std::cerr << "Trim complete: " << stats.initial_edges << " -> " << stats.final_edges
                  << " edges; removed " << stats.removed_count << ".\n";
        return 0;
    } catch (std::exception const& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 2;
    }
}
