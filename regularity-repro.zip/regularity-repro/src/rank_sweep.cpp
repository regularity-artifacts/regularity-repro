#include "ht/trim_engine.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <vector>

namespace ht {

std::vector<int> TrimEngine::xor_sorted(std::vector<int> const& A, std::vector<int> const& B) {
    std::vector<int> C;
    C.reserve(A.size() + B.size());
    size_t i = 0, j = 0;
    while (i < A.size() || j < B.size()) {
        if (j >= B.size() || (i < A.size() && A[i] < B[j])) {
            C.push_back(A[i++]);
        } else if (i >= A.size() || B[j] < A[i]) {
            C.push_back(B[j++]);
        } else {
            ++i; ++j;
        }
    }
    return C;
}

void TrimEngine::xor_sorted_inplace(std::vector<int>& A, std::vector<int> const& B) {
    std::vector<int> C;
    C.reserve(A.size() + B.size());
    size_t i = 0, j = 0;
    while (i < A.size() || j < B.size()) {
        if (j >= B.size() || (i < A.size() && A[i] < B[j])) {
            C.push_back(A[i++]);
        } else if (i >= A.size() || B[j] < A[i]) {
            C.push_back(B[j++]);
        } else {
            ++i; ++j;
        }
    }
    A.swap(C);
}

bool TrimEngine::insert_boundary_column(std::vector<int> col,
                                        std::vector<std::vector<int>>& basis,
                                        int boundary_dim) {
    if (boundary_dim == 2) ++st_.boundary2_columns;
    else if (boundary_dim == 3) ++st_.boundary3_columns;

    std::sort(col.begin(), col.end());
    col.erase(std::unique(col.begin(), col.end()), col.end());

    while (!col.empty()) {
        int pivot = col.back();
        if (basis[pivot].empty()) {
            basis[pivot] = std::move(col);
            if (boundary_dim == 2) ++st_.boundary2_rank_increments;
            else if (boundary_dim == 3) ++st_.boundary3_rank_increments;
            return true;
        }
        if (boundary_dim == 2) ++st_.boundary2_xor_ops;
        else if (boundary_dim == 3) ++st_.boundary3_xor_ops;
        xor_sorted_inplace(col, basis[pivot]);
    }
    return false;
}

bool TrimEngine::lower_link_h1_future_zero(LowerLink2 const& L, double x) {
    const int nv = static_cast<int>(L.V.size());
    const int ne = static_cast<int>(L.E.size());
    const int nt = static_cast<int>(L.T.size());

    std::vector<int> vo(nv), eo(ne), to(nt);
    std::iota(vo.begin(), vo.end(), 0);
    std::iota(eo.begin(), eo.end(), 0);
    std::iota(to.begin(), to.end(), 0);

    std::sort(vo.begin(), vo.end(), [&](int a, int b){
        if (std::abs(L.V[a].alpha - L.V[b].alpha) > EPS) return L.V[a].alpha < L.V[b].alpha;
        return L.V[a].q < L.V[b].q;
    });
    std::sort(eo.begin(), eo.end(), [&](int a, int b){
        auto const& A = L.E[a];
        auto const& B = L.E[b];
        if (std::abs(A.beta - B.beta) > EPS) return A.beta < B.beta;
        if (A.a != B.a) return A.a < B.a;
        return A.b < B.b;
    });
    std::sort(to.begin(), to.end(), [&](int a, int b){
        auto const& A = L.T[a];
        auto const& B = L.T[b];
        if (std::abs(A.gamma - B.gamma) > EPS) return A.gamma < B.gamma;
        if (A.a != B.a) return A.a < B.a;
        if (A.b != B.b) return A.b < B.b;
        return A.c < B.c;
    });

    DSU dsu(nv);
    std::vector<char> active(nv, 0);
    int active_vertices = 0;
    int active_edges = 0;
    int components = 0;
    int rank_b2 = 0;

    std::vector<std::vector<int>> basis(static_cast<size_t>(ne));

    auto add_vertex = [&](int i) {
        if (!active[i]) {
            active[i] = 1;
            ++active_vertices;
            ++components;
        }
    };
    auto add_edge = [&](int id) {
        auto const& e = L.E[id];
        ++active_edges;
        if (active[e.a] && active[e.b] && dsu.unite(e.a, e.b)) --components;
    };
    auto add_triangle = [&](int id) {
        auto const& t = L.T[id];
        int eab = L.local_edge_id(t.a, t.b);
        int eac = L.local_edge_id(t.a, t.c);
        int ebc = L.local_edge_id(t.b, t.c);
        if (eab < 0 || eac < 0 || ebc < 0) return;
        const double r0 = now_seconds();
        bool inc = insert_boundary_column({eab, eac, ebc}, basis, 2);
        st_.rank_boundary2_seconds += now_seconds() - r0;
        if (inc) ++rank_b2;
    };

    size_t vi = 0, ei = 0, ti = 0;

    auto add_upto = [&](double tval) {
        while (vi < vo.size() && L.V[vo[vi]].alpha <= tval + EPS) add_vertex(vo[vi++]);
        while (ei < eo.size() && L.E[eo[ei]].beta <= tval + EPS) add_edge(eo[ei++]);
        while (ti < to.size() && L.T[to[ti]].gamma <= tval + EPS) add_triangle(to[ti++]);
    };

    auto check_current = [&]() -> bool {
        if (active_vertices == 0 || components != 1) return false;
        const int beta1 = active_edges - active_vertices + components - rank_b2;
        return beta1 == 0;
    };

    add_upto(x);
    if (!check_current()) return false;

    while (vi < vo.size() || ei < eo.size() || ti < to.size()) {
        double tval = std::numeric_limits<double>::infinity();
        if (vi < vo.size()) tval = std::min(tval, L.V[vo[vi]].alpha);
        if (ei < eo.size()) tval = std::min(tval, L.E[eo[ei]].beta);
        if (ti < to.size()) tval = std::min(tval, L.T[to[ti]].gamma);
        add_upto(tval);
        if (!check_current()) return false;
    }

    return true;
}

bool TrimEngine::lower_link_h2_future_zero(LowerLink2 const& L, double x) {
    const int nv = static_cast<int>(L.V.size());
    const int ne = static_cast<int>(L.E.size());
    const int nt = static_cast<int>(L.T.size());
    const int nq = static_cast<int>(L.Q.size());

    std::vector<int> vo(nv), eo(ne), to(nt), qo(nq);
    std::iota(vo.begin(), vo.end(), 0);
    std::iota(eo.begin(), eo.end(), 0);
    std::iota(to.begin(), to.end(), 0);
    std::iota(qo.begin(), qo.end(), 0);

    std::sort(vo.begin(), vo.end(), [&](int a, int b){
        if (std::abs(L.V[a].alpha - L.V[b].alpha) > EPS) return L.V[a].alpha < L.V[b].alpha;
        return L.V[a].q < L.V[b].q;
    });
    std::sort(eo.begin(), eo.end(), [&](int a, int b){
        auto const& A = L.E[a]; auto const& B = L.E[b];
        if (std::abs(A.beta - B.beta) > EPS) return A.beta < B.beta;
        if (A.a != B.a) return A.a < B.a;
        return A.b < B.b;
    });
    std::sort(to.begin(), to.end(), [&](int a, int b){
        auto const& A = L.T[a]; auto const& B = L.T[b];
        if (std::abs(A.gamma - B.gamma) > EPS) return A.gamma < B.gamma;
        if (A.a != B.a) return A.a < B.a;
        if (A.b != B.b) return A.b < B.b;
        return A.c < B.c;
    });
    std::sort(qo.begin(), qo.end(), [&](int a, int b){
        auto const& A = L.Q[a]; auto const& B = L.Q[b];
        if (std::abs(A.delta - B.delta) > EPS) return A.delta < B.delta;
        if (A.a != B.a) return A.a < B.a;
        if (A.b != B.b) return A.b < B.b;
        if (A.c != B.c) return A.c < B.c;
        return A.d < B.d;
    });

    struct Snapshot {
        double time = 0.0;
        int required_rank_b3 = 0;  // dim ker(partial_2) = active_triangles - rank(partial_2)
    };
    std::vector<Snapshot> snapshots;
    snapshots.reserve(static_cast<size_t>(nv + ne + nt + 1));

    // Phase 1: ignore tetrahedra.  Sweep the 2-skeleton, verify the H0/H1
    // conditions throughout the future interval, and record the amount of
    // boundary_3 rank needed at each relevant time.  This delays all expensive
    // boundary_3 work until after cheap H1 failures have already been rejected.
    DSU dsu(nv);
    std::vector<char> active(nv, 0);
    int active_vertices = 0;
    int active_edges = 0;
    int active_triangles = 0;
    int components = 0;
    int rank_b2 = 0;

    std::vector<std::vector<int>> basis_b2(static_cast<size_t>(ne));

    auto add_vertex = [&](int i) {
        if (!active[i]) { active[i] = 1; ++active_vertices; ++components; }
    };
    auto add_edge = [&](int id) {
        auto const& e = L.E[id];
        ++active_edges;
        if (active[e.a] && active[e.b] && dsu.unite(e.a, e.b)) --components;
    };
    auto add_triangle = [&](int id) {
        auto const& t = L.T[id];
        ++active_triangles;
        int eab = L.local_edge_id(t.a, t.b);
        int eac = L.local_edge_id(t.a, t.c);
        int ebc = L.local_edge_id(t.b, t.c);
        if (eab < 0 || eac < 0 || ebc < 0) return;
        const double r0 = now_seconds();
        bool inc = insert_boundary_column({eab, eac, ebc}, basis_b2, 2);
        st_.rank_boundary2_seconds += now_seconds() - r0;
        if (inc) ++rank_b2;
    };

    size_t vi = 0, ei = 0, ti = 0;
    auto add_2skeleton_upto = [&](double tval) {
        while (vi < vo.size() && L.V[vo[vi]].alpha <= tval + EPS) add_vertex(vo[vi++]);
        while (ei < eo.size() && L.E[eo[ei]].beta <= tval + EPS) add_edge(eo[ei++]);
        while (ti < to.size() && L.T[to[ti]].gamma <= tval + EPS) add_triangle(to[ti++]);
    };

    auto check_h1_and_record = [&](double tval) -> bool {
        if (active_vertices == 0 || components != 1) return false;
        int beta1 = active_edges - active_vertices + components - rank_b2;
        if (beta1 != 0) return false;
        int required = active_triangles - rank_b2;
        if (required < 0) return false; // numerical/logical guard; should not happen over F2 chain complexes
        snapshots.push_back({tval, required});
        return true;
    };

    add_2skeleton_upto(x);
    if (!check_h1_and_record(x)) return false;

    while (vi < vo.size() || ei < eo.size() || ti < to.size()) {
        double tval = std::numeric_limits<double>::infinity();
        if (vi < vo.size()) tval = std::min(tval, L.V[vo[vi]].alpha);
        if (ei < eo.size()) tval = std::min(tval, L.E[eo[ei]].beta);
        if (ti < to.size()) tval = std::min(tval, L.T[to[ti]].gamma);
        add_2skeleton_upto(tval);
        if (!check_h1_and_record(tval)) return false;
    }

    // If the 2-skeleton has no possible H2 at any future time, no boundary_3
    // columns are needed.  This happens frequently in small/geometric links.
    int max_required = 0;
    for (auto const& s : snapshots) max_required = std::max(max_required, s.required_rank_b3);
    if (max_required == 0) {
        st_.boundary3_skipped_after_zero += static_cast<long long>(nq);
        return true;
    }

    // Phase 2: sweep tetrahedra only as far as needed.  At every recorded
    // 2-skeleton event time t, rank(partial_3(t)) must equal required_rank_b3(t).
    // Before doing reductions, reject immediately if there are not even enough
    // tetrahedra born by t to span the required rank.
    std::vector<std::vector<int>> basis_b3(static_cast<size_t>(nt));
    int rank_b3 = 0;
    size_t q_available = 0;
    size_t qi = 0;

    auto add_tetrahedron = [&](int id) {
        auto const& q = L.Q[id];
        int tabc = L.local_triangle_id(q.a, q.b, q.c);
        int tabd = L.local_triangle_id(q.a, q.b, q.d);
        int tacd = L.local_triangle_id(q.a, q.c, q.d);
        int tbcd = L.local_triangle_id(q.b, q.c, q.d);
        if (tabc < 0 || tabd < 0 || tacd < 0 || tbcd < 0) return;
        const double r0 = now_seconds();
        bool inc = insert_boundary_column({tabc, tabd, tacd, tbcd}, basis_b3, 3);
        st_.rank_boundary3_seconds += now_seconds() - r0;
        if (inc) ++rank_b3;
    };

    for (auto const& snap : snapshots) {
        while (q_available < qo.size() && L.Q[qo[q_available]].delta <= snap.time + EPS) {
            ++q_available;
        }
        if (static_cast<int>(q_available) < snap.required_rank_b3) {
            ++st_.boundary3_feasibility_rejects;
            return false;
        }
        while (qi < q_available) {
            add_tetrahedron(qo[qi++]);
        }
        if (rank_b3 != snap.required_rank_b3) return false;
    }

    // No later 3-simplex can create H2; it can only add dependent columns once
    // rank(partial_3) already spans ker(partial_2).  Hence remaining tetrahedra
    // need not be reduced.
    if (qi < qo.size()) {
        st_.boundary3_skipped_after_zero += static_cast<long long>(qo.size() - qi);
    }

    return true;
}

} // namespace ht
