#include "ht/trim_engine.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <tuple>
#include <vector>

namespace ht {

namespace {
constexpr double INF_D = std::numeric_limits<double>::infinity();
}

double TrimEngine::first_h0_failure_time(LowerLink2 const& L, double x) const {
    const int m = static_cast<int>(L.V.size());
    if (m == 0) return x;

    std::vector<int> vo(m);
    std::iota(vo.begin(), vo.end(), 0);
    std::sort(vo.begin(), vo.end(), [&](int a, int b){
        if (std::abs(L.V[a].alpha - L.V[b].alpha) > EPS) return L.V[a].alpha < L.V[b].alpha;
        return L.V[a].q < L.V[b].q;
    });

    std::vector<int> eo(L.E.size());
    std::iota(eo.begin(), eo.end(), 0);
    std::sort(eo.begin(), eo.end(), [&](int a, int b){
        auto const& A = L.E[a];
        auto const& B = L.E[b];
        if (std::abs(A.beta - B.beta) > EPS) return A.beta < B.beta;
        if (A.a != B.a) return A.a < B.a;
        return A.b < B.b;
    });

    DSU dsu(m);
    std::vector<char> active(m, 0);
    int active_count = 0;
    int components = 0;

    auto add_v = [&](int i) {
        if (!active[i]) {
            active[i] = 1;
            ++active_count;
            ++components;
        }
    };
    auto add_e = [&](int id) {
        auto const& le = L.E[id];
        if (active[le.a] && active[le.b] && dsu.unite(le.a, le.b)) --components;
    };
    auto ok = [&]() { return active_count > 0 && components == 1; };

    size_t vi = 0, ei = 0;
    auto add_upto = [&](double t) {
        while (vi < vo.size() && L.V[vo[vi]].alpha <= t + EPS) add_v(vo[vi++]);
        while (ei < eo.size() && L.E[eo[ei]].beta <= t + EPS) add_e(eo[ei++]);
    };

    add_upto(x);
    if (!ok()) return x;

    while (vi < vo.size() || ei < eo.size()) {
        double t = INF_D;
        if (vi < vo.size()) t = std::min(t, L.V[vo[vi]].alpha);
        if (ei < eo.size()) t = std::min(t, L.E[eo[ei]].beta);
        add_upto(t);
        if (!ok()) return t;
    }
    return INF_D;
}

double TrimEngine::first_h1_failure_time(LowerLink2 const& L, double x) {
    const int nv = static_cast<int>(L.V.size());
    const int ne = static_cast<int>(L.E.size());
    const int nt = static_cast<int>(L.T.size());

    std::vector<int> vo(nv), eo(ne), to(nt);
    std::iota(vo.begin(), vo.end(), 0);
    std::iota(eo.begin(), eo.end(), 0);
    std::iota(to.begin(), to.end(), 0);

    std::sort(vo.begin(), vo.end(), [&](int a, int b){
        if (std::abs(L.V[a].alpha - L.V[b].alpha) > EPS) return L.V[a].alpha < L.V[b].alpha;
        return L.V[a].q < L.V[b].q;
    });
    std::sort(eo.begin(), eo.end(), [&](int a, int b){
        auto const& A = L.E[a]; auto const& B = L.E[b];
        if (std::abs(A.beta - B.beta) > EPS) return A.beta < B.beta;
        if (A.a != B.a) return A.a < B.a;
        return A.b < B.b;
    });
    std::sort(to.begin(), to.end(), [&](int a, int b){
        auto const& A = L.T[a]; auto const& B = L.T[b];
        if (std::abs(A.gamma - B.gamma) > EPS) return A.gamma < B.gamma;
        if (A.a != B.a) return A.a < B.a;
        if (A.b != B.b) return A.b < B.b;
        return A.c < B.c;
    });

    DSU dsu(nv);
    std::vector<char> active(nv, 0);
    int active_vertices = 0;
    int active_edges = 0;
    int components = 0;
    int rank_b2 = 0;
    std::vector<std::vector<int>> basis(static_cast<size_t>(ne));

    auto add_vertex = [&](int i) {
        if (!active[i]) { active[i] = 1; ++active_vertices; ++components; }
    };
    auto add_edge = [&](int id) {
        auto const& e = L.E[id];
        ++active_edges;
        if (active[e.a] && active[e.b] && dsu.unite(e.a, e.b)) --components;
    };
    auto add_triangle = [&](int id) {
        auto const& t = L.T[id];
        int eab = L.local_edge_id(t.a, t.b);
        int eac = L.local_edge_id(t.a, t.c);
        int ebc = L.local_edge_id(t.b, t.c);
        if (eab < 0 || eac < 0 || ebc < 0) return;
        const double r0 = now_seconds();
        bool inc = insert_boundary_column({eab, eac, ebc}, basis, 2);
        st_.rank_boundary2_seconds += now_seconds() - r0;
        if (inc) ++rank_b2;
    };
    auto ok = [&]() {
        if (active_vertices == 0 || components != 1) return false;
        const int beta1 = active_edges - active_vertices + components - rank_b2;
        return beta1 == 0;
    };

    size_t vi = 0, ei = 0, ti = 0;
    auto add_upto = [&](double t) {
        while (vi < vo.size() && L.V[vo[vi]].alpha <= t + EPS) add_vertex(vo[vi++]);
        while (ei < eo.size() && L.E[eo[ei]].beta <= t + EPS) add_edge(eo[ei++]);
        while (ti < to.size() && L.T[to[ti]].gamma <= t + EPS) add_triangle(to[ti++]);
    };

    add_upto(x);
    if (!ok()) return x;

    while (vi < vo.size() || ei < eo.size() || ti < to.size()) {
        double t = INF_D;
        if (vi < vo.size()) t = std::min(t, L.V[vo[vi]].alpha);
        if (ei < eo.size()) t = std::min(t, L.E[eo[ei]].beta);
        if (ti < to.size()) t = std::min(t, L.T[to[ti]].gamma);
        add_upto(t);
        if (!ok()) return t;
    }
    return INF_D;
}

double TrimEngine::first_h2_failure_time(LowerLink2 const& L, double x) {
    const int nv = static_cast<int>(L.V.size());
    const int ne = static_cast<int>(L.E.size());
    const int nt = static_cast<int>(L.T.size());
    const int nq = static_cast<int>(L.Q.size());

    std::vector<int> vo(nv), eo(ne), to(nt), qo(nq);
    std::iota(vo.begin(), vo.end(), 0);
    std::iota(eo.begin(), eo.end(), 0);
    std::iota(to.begin(), to.end(), 0);
    std::iota(qo.begin(), qo.end(), 0);

    std::sort(vo.begin(), vo.end(), [&](int a, int b){
        if (std::abs(L.V[a].alpha - L.V[b].alpha) > EPS) return L.V[a].alpha < L.V[b].alpha;
        return L.V[a].q < L.V[b].q;
    });
    std::sort(eo.begin(), eo.end(), [&](int a, int b){
        auto const& A = L.E[a]; auto const& B = L.E[b];
        if (std::abs(A.beta - B.beta) > EPS) return A.beta < B.beta;
        if (A.a != B.a) return A.a < B.a;
        return A.b < B.b;
    });
    std::sort(to.begin(), to.end(), [&](int a, int b){
        auto const& A = L.T[a]; auto const& B = L.T[b];
        if (std::abs(A.gamma - B.gamma) > EPS) return A.gamma < B.gamma;
        if (A.a != B.a) return A.a < B.a;
        if (A.b != B.b) return A.b < B.b;
        return A.c < B.c;
    });
    std::sort(qo.begin(), qo.end(), [&](int a, int b){
        auto const& A = L.Q[a]; auto const& B = L.Q[b];
        if (std::abs(A.delta - B.delta) > EPS) return A.delta < B.delta;
        if (A.a != B.a) return A.a < B.a;
        if (A.b != B.b) return A.b < B.b;
        if (A.c != B.c) return A.c < B.c;
        return A.d < B.d;
    });

    struct Snapshot { double time; int required_rank_b3; };
    std::vector<Snapshot> snapshots;

    DSU dsu(nv);
    std::vector<char> active(nv, 0);
    int active_vertices = 0, active_edges = 0, active_triangles = 0, components = 0, rank_b2 = 0;
    std::vector<std::vector<int>> basis_b2(static_cast<size_t>(ne));

    auto add_vertex = [&](int i) {
        if (!active[i]) { active[i] = 1; ++active_vertices; ++components; }
    };
    auto add_edge = [&](int id) {
        auto const& e = L.E[id];
        ++active_edges;
        if (active[e.a] && active[e.b] && dsu.unite(e.a, e.b)) --components;
    };
    auto add_triangle = [&](int id) {
        auto const& t = L.T[id];
        ++active_triangles;
        int eab = L.local_edge_id(t.a, t.b);
        int eac = L.local_edge_id(t.a, t.c);
        int ebc = L.local_edge_id(t.b, t.c);
        if (eab < 0 || eac < 0 || ebc < 0) return;
        const double r0 = now_seconds();
        bool inc = insert_boundary_column({eab, eac, ebc}, basis_b2, 2);
        st_.rank_boundary2_seconds += now_seconds() - r0;
        if (inc) ++rank_b2;
    };
    size_t vi = 0, ei = 0, ti = 0;
    auto add_2_upto2 = [&](double t) {
        while (vi < vo.size() && L.V[vo[vi]].alpha <= t + EPS) add_vertex(vo[vi++]);
        while (ei < eo.size() && L.E[eo[ei]].beta <= t + EPS) add_edge(eo[ei++]);
        while (ti < to.size() && L.T[to[ti]].gamma <= t + EPS) add_triangle(to[ti++]);
    };
    // IMPORTANT: beta_1 and beta_2 are independent conditions -- beta_2 can
    // fail strictly earlier than beta_1 does (not enough tetrahedra to kill
    // a 2-cycle can happen before the 2-skeleton itself even disconnects).
    // So this must NOT return the moment beta_1 fails; it has to keep the
    // snapshots gathered so far, let the tetrahedra phase search them for a
    // possibly-earlier beta_2 failure, and report the minimum of the two.
    auto check_h1_record = [&](double t) -> bool {
        if (active_vertices == 0 || components != 1) return false;
        int beta1 = active_edges - active_vertices + components - rank_b2;
        if (beta1 != 0) return false;
        int required = active_triangles - rank_b2;
        if (required < 0) return false;
        snapshots.push_back({t, required});
        return true;
    };

    double h1_fail_time = INF_D;
    add_2_upto2(x);
    if (!check_h1_record(x)) {
        h1_fail_time = x;
    } else {
        while (vi < vo.size() || ei < eo.size() || ti < to.size()) {
            double t = INF_D;
            if (vi < vo.size()) t = std::min(t, L.V[vo[vi]].alpha);
            if (ei < eo.size()) t = std::min(t, L.E[eo[ei]].beta);
            if (ti < to.size()) t = std::min(t, L.T[to[ti]].gamma);
            add_2_upto2(t);
            if (!check_h1_record(t)) { h1_fail_time = t; break; }
        }
    }

    double best = h1_fail_time;
    while (!snapshots.empty() && snapshots.back().time > best + EPS) snapshots.pop_back();

    int max_required = 0;
    for (auto const& s : snapshots) max_required = std::max(max_required, s.required_rank_b3);
    if (max_required == 0) {
        st_.boundary3_skipped_after_zero += static_cast<long long>(nq);
        return best;
    }

    std::vector<std::vector<int>> basis_b3(static_cast<size_t>(nt));
    int rank_b3 = 0;
    size_t q_available = 0, qi = 0;

    auto add_tetrahedron = [&](int id) {
        auto const& q = L.Q[id];
        int tabc = L.local_triangle_id(q.a, q.b, q.c);
        int tabd = L.local_triangle_id(q.a, q.b, q.d);
        int tacd = L.local_triangle_id(q.a, q.c, q.d);
        int tbcd = L.local_triangle_id(q.b, q.c, q.d);
        if (tabc < 0 || tabd < 0 || tacd < 0 || tbcd < 0) return;
        const double r0 = now_seconds();
        bool inc = insert_boundary_column({tabc, tabd, tacd, tbcd}, basis_b3, 3);
        st_.rank_boundary3_seconds += now_seconds() - r0;
        if (inc) ++rank_b3;
    };

    for (auto const& snap : snapshots) {
        if (snap.time > best + EPS) break; // cannot improve on the current bound
        while (q_available < qo.size() && L.Q[qo[q_available]].delta <= snap.time + EPS) ++q_available;
        if (static_cast<int>(q_available) < snap.required_rank_b3) {
            ++st_.boundary3_feasibility_rejects;
            best = std::min(best, snap.time);
            break;
        }
        while (qi < q_available) add_tetrahedron(qo[qi++]);
        if (rank_b3 != snap.required_rank_b3) { best = std::min(best, snap.time); break; }
    }
    if (qi < qo.size()) st_.boundary3_skipped_after_zero += static_cast<long long>(qo.size() - qi);
    return best;
}

TrimEngine::DelayDecision TrimEngine::homology_delay_decision(EdgeId eid) {
    DelayDecision d;
    if (!G_.active(eid)) return d;
    auto const& e = G_.edge(eid);

    const double t0 = now_seconds();
    ++st_.ph_calls;

    double build_seconds = 0.0;
    double reduction_seconds = 0.0;
    double fail_time = e.w;

    auto finish = [&](double first_failure, LinkSummary const& Lsum) {
        d.link = Lsum;
        if (first_failure <= e.w + EPS) {
            d.action = DelayAction::Keep;
            d.new_weight = e.w;
            ++st_.ph_fail;
        } else if (std::isinf(first_failure)) {
            d.action = DelayAction::Delete;
            d.new_weight = INF_D;
            ++st_.ph_success;
        } else {
            d.action = DelayAction::Delay;
            d.new_weight = first_failure;
            ++st_.ph_success;
        }
        st_.ph_seconds += now_seconds() - t0;
        st_.ph_lower_link_seconds += build_seconds;
        st_.ph_reduction_seconds += reduction_seconds;
        return d;
    };

    if (opt_.max_global_dim == 0) {
        LinkSummary S;
        bool ok = k0_raw(eid, &S);
        return finish(ok ? INF_D : e.w, S);
    }

    if (opt_.force_general || opt_.max_global_dim >= 4) {
        GeneralLowerLink& gl = build_general_lower_link(eid);
        double t = homology_failure_time_general(gl, e.w, opt_.max_global_dim);
        LinkSummary S;
        S.vertices = gl.m();
        int total = gl.m();
        for (size_t d = 1; d < gl.levels.size(); ++d) total += static_cast<int>(gl.levels[d].size());
        if (gl.levels.size() > 1) S.edges = static_cast<int>(gl.levels[1].size());
        if (gl.levels.size() > 2) S.triangles = static_cast<int>(gl.levels[2].size());
        if (gl.levels.size() > 3) S.tetrahedra = static_cast<int>(gl.levels[3].size());
        S.simplices = total;
        return finish(t, S);
    }

    const double b0 = now_seconds();
    LowerLink2& L = build_lower_link_1_skeleton(eid);
    const double b1 = now_seconds();
    build_seconds += b1 - b0;
    st_.build_1_skeleton_seconds += b1 - b0;

    LinkSummary S;
    S.vertices = static_cast<int>(L.V.size());
    S.edges = static_cast<int>(L.E.size());

    if (opt_.max_global_dim == 1) {
        const double r0 = now_seconds();
        fail_time = first_h0_failure_time(L, e.w);
        const double r1 = now_seconds();
        reduction_seconds += r1 - r0;
        st_.connectivity_seconds += r1 - r0;
        S.simplices = S.vertices + S.edges;
        return finish(fail_time, S);
    }

    const double tri0 = now_seconds();
    build_lower_link_triangles(L);
    const double tri1 = now_seconds();
    build_seconds += tri1 - tri0;
    st_.build_triangles_seconds += tri1 - tri0;
    S.triangles = static_cast<int>(L.T.size());

    if (opt_.max_global_dim == 2) {
        const double r0 = now_seconds();
        fail_time = first_h1_failure_time(L, e.w);
        const double r1 = now_seconds();
        reduction_seconds += r1 - r0;
        S.simplices = S.vertices + S.edges + S.triangles;
        return finish(fail_time, S);
    }

    const double tet0 = now_seconds();
    build_lower_link_tetrahedra(L);
    const double tet1 = now_seconds();
    build_seconds += tet1 - tet0;
    st_.build_tetrahedra_seconds += tet1 - tet0;
    S.tetrahedra = static_cast<int>(L.Q.size());

    const double r0 = now_seconds();
    fail_time = first_h2_failure_time(L, e.w);
    const double r1 = now_seconds();
    reduction_seconds += r1 - r0;
    S.simplices = S.vertices + S.edges + S.triangles + S.tetrahedra;
    return finish(fail_time, S);
}

} // namespace ht
