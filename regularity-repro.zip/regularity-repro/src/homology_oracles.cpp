#include "ht/trim_engine.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <stdexcept>

namespace ht {

bool TrimEngine::k0_raw(EdgeId eid, LinkSummary* L) const {
    auto const& e = G_.edge(eid);
    auto common = G_.active_common_neighbors(e.u, e.v);
    int present = 0;
    for (int q : common) {
        double a = std::max(G_.weight(e.u,q), G_.weight(e.v,q));
        if (a <= e.w + EPS) ++present;
    }
    if (L) { L->vertices=(int)common.size(); L->edges=0; L->simplices=L->vertices; }
    return present > 0;
}

bool TrimEngine::lower_link_h0_future_connected(LowerLink2 const& L, double x) const {
    const int m = static_cast<int>(L.V.size());
    if (m == 0) return false;

    std::vector<int> vo(m);
    std::iota(vo.begin(), vo.end(), 0);
    std::sort(vo.begin(), vo.end(), [&](int a, int b){
        if (std::abs(L.V[a].alpha - L.V[b].alpha) > EPS) return L.V[a].alpha < L.V[b].alpha;
        return L.V[a].q < L.V[b].q;
    });

    std::vector<int> eo(L.E.size());
    std::iota(eo.begin(), eo.end(), 0);
    std::sort(eo.begin(), eo.end(), [&](int a, int b){
        auto const& A = L.E[a];
        auto const& B = L.E[b];
        if (std::abs(A.beta - B.beta) > EPS) return A.beta < B.beta;
        if (A.a != B.a) return A.a < B.a;
        return A.b < B.b;
    });

    DSU dsu(m);
    std::vector<char> active(m, 0);
    int active_count = 0;
    int components = 0;

    auto add_v = [&](int i) {
        if (!active[i]) {
            active[i] = 1;
            ++active_count;
            ++components;
        }
    };
    auto add_e = [&](int id) {
        auto const& le = L.E[id];
        if (active[le.a] && active[le.b] && dsu.unite(le.a, le.b)) --components;
    };

    size_t vi = 0, ei = 0;
    auto add_upto = [&](double t) {
        while (vi < vo.size() && L.V[vo[vi]].alpha <= t + EPS) add_v(vo[vi++]);
        while (ei < eo.size() && L.E[eo[ei]].beta <= t + EPS) add_e(eo[ei++]);
    };

    add_upto(x);
    if (active_count == 0 || components != 1) return false;

    while (vi < vo.size() || ei < eo.size()) {
        double nt = std::numeric_limits<double>::infinity();
        if (vi < vo.size()) nt = std::min(nt, L.V[vo[vi]].alpha);
        if (ei < eo.size()) nt = std::min(nt, L.E[eo[ei]].beta);
        add_upto(nt);
        if (active_count == 0 || components != 1) return false;
    }
    return true;
}

bool TrimEngine::k1_raw(EdgeId eid, LinkSummary* S) {
    auto const& e = G_.edge(eid);
    const double build0 = now_seconds();
    LowerLink2& L = build_lower_link_1_skeleton(eid);
    const double build1 = now_seconds();
    const double build_seconds = build1 - build0;

    if (S) {
        S->vertices = static_cast<int>(L.V.size());
        S->edges = static_cast<int>(L.E.size());
        S->triangles = 0;
        S->tetrahedra = 0;
        S->simplices = S->vertices + S->edges;
    }

    const double red0 = now_seconds();
    bool ok = lower_link_h0_future_connected(L, e.w);
    const double red1 = now_seconds();
    const double red_seconds = red1 - red0;

    st_.ph_lower_link_seconds += build_seconds;
    st_.build_1_skeleton_seconds += build_seconds;
    st_.ph_reduction_seconds += red_seconds;
    st_.connectivity_seconds += red_seconds;
    return ok;
}

bool TrimEngine::forest_future_connected_with_active_edges(LowerLink2 const& L,
                                                           std::vector<char> const& edge_active,
                                                           double x) const {
    const int nv = static_cast<int>(L.V.size());
    if (nv == 0) return false;

    std::vector<int> vo(nv);
    std::iota(vo.begin(), vo.end(), 0);
    std::sort(vo.begin(), vo.end(), [&](int a, int b){
        if (std::abs(L.V[a].alpha - L.V[b].alpha) > EPS) return L.V[a].alpha < L.V[b].alpha;
        return L.V[a].q < L.V[b].q;
    });

    std::vector<int> eo;
    eo.reserve(L.E.size());
    for (int i = 0; i < static_cast<int>(L.E.size()); ++i) {
        if (edge_active.empty() || edge_active[i]) eo.push_back(i);
    }
    std::sort(eo.begin(), eo.end(), [&](int a, int b){
        auto const& A = L.E[a];
        auto const& B = L.E[b];
        if (std::abs(A.beta - B.beta) > EPS) return A.beta < B.beta;
        if (A.a != B.a) return A.a < B.a;
        return A.b < B.b;
    });

    DSU dsu(nv);
    std::vector<char> active_v(nv, 0);
    int active_vertices = 0;
    int active_edges = 0;
    int components = 0;

    auto add_vertex = [&](int i) {
        if (!active_v[i]) {
            active_v[i] = 1;
            ++active_vertices;
            ++components;
        }
    };
    auto add_edge = [&](int id) {
        auto const& e = L.E[id];
        ++active_edges;
        if (active_v[e.a] && active_v[e.b] && dsu.unite(e.a, e.b)) --components;
    };

    size_t vi = 0, ei = 0;
    auto add_upto = [&](double tval) {
        while (vi < vo.size() && L.V[vo[vi]].alpha <= tval + EPS) add_vertex(vo[vi++]);
        while (ei < eo.size() && L.E[eo[ei]].beta <= tval + EPS) add_edge(eo[ei++]);
    };
    auto check_current = [&]() -> bool {
        if (active_vertices == 0 || components != 1) return false;
        const int beta1_graph = active_edges - active_vertices + components;
        return beta1_graph == 0;
    };

    add_upto(x);
    if (!check_current()) return false;

    while (vi < vo.size() || ei < eo.size()) {
        double tval = std::numeric_limits<double>::infinity();
        if (vi < vo.size()) tval = std::min(tval, L.V[vo[vi]].alpha);
        if (ei < eo.size()) tval = std::min(tval, L.E[eo[ei]].beta);
        add_upto(tval);
        if (!check_current()) return false;
    }
    return true;
}

bool TrimEngine::local_edge_k1_certifies(LowerLink2 const& L,
                                         std::vector<char> const& active_edge,
                                         int local_eid,
                                         double preserve_from) const {
    auto const& e = L.E[local_eid];
    const double start = std::max(e.beta, preserve_from);
    LowerLink2& A = build_local_edge_lower_link_1_skeleton(L, active_edge, local_eid);
    return lower_link_h0_future_connected(A, start);
}

bool TrimEngine::recursive_trim_prefilter_forest(LowerLink2 const& L, double x) {
    const double t0 = now_seconds();
    ++st_.recursive_prefilter_calls;

    std::vector<char> active_edge(L.E.size(), 1);
    bool changed = true;

    while (changed) {
        changed = false;
        std::vector<int> order;
        order.reserve(L.E.size());
        for (int i = 0; i < static_cast<int>(L.E.size()); ++i) {
            if (active_edge[i]) order.push_back(i);
        }
        std::sort(order.begin(), order.end(), [&](int a, int b){
            auto const& A = L.E[a];
            auto const& B = L.E[b];
            if (std::abs(A.beta - B.beta) > EPS) return A.beta > B.beta;
            if (A.a != B.a) return A.a < B.a;
            return A.b < B.b;
        });

        for (int eid : order) {
            if (!active_edge[eid]) continue;
            ++st_.recursive_prefilter_edge_tests;
            if (local_edge_k1_certifies(L, active_edge, eid, x)) {
                active_edge[eid] = 0;
                ++st_.recursive_prefilter_edge_removals;
                changed = true;
            }
        }
    }

    bool ok = forest_future_connected_with_active_edges(L, active_edge, x);
    st_.recursive_prefilter_seconds += now_seconds() - t0;
    if (ok) ++st_.recursive_prefilter_success;
    else ++st_.recursive_prefilter_fail;
    return ok;
}


bool TrimEngine::local_edge_k2_certifies(LowerLink2 const& L,
                                         std::vector<char> const& active_edge,
                                         int local_eid,
                                         double preserve_from) {
    auto const& e = L.E[local_eid];
    const double start = std::max(e.beta, preserve_from);

    LowerLink2& A = build_local_edge_lower_link_1_skeleton(L, active_edge, local_eid);

    if (!lower_link_h0_future_connected(A, start)) return false;

    const int cycle_rank = static_cast<int>(A.E.size()) - static_cast<int>(A.V.size()) + 1;
    if (cycle_rank <= 0) return true;

    build_lower_link_triangles(A);
    if (static_cast<int>(A.T.size()) < cycle_rank) return false;

    return lower_link_h1_future_zero(A, start);
}

bool TrimEngine::recursive_trim_prefilter_forest_k2(LowerLink2 const& L, double x) {
    const double t0 = now_seconds();
    ++st_.recursive_prefilter_calls;

    std::vector<char> active_edge(L.E.size(), 1);
    bool changed = true;

    while (changed) {
        changed = false;
        std::vector<int> order;
        order.reserve(L.E.size());
        for (int i = 0; i < static_cast<int>(L.E.size()); ++i) {
            if (active_edge[i]) order.push_back(i);
        }
        std::sort(order.begin(), order.end(), [&](int a, int b){
            auto const& A = L.E[a];
            auto const& B = L.E[b];
            if (std::abs(A.beta - B.beta) > EPS) return A.beta > B.beta;
            if (A.a != B.a) return A.a < B.a;
            return A.b < B.b;
        });

        for (int eid : order) {
            if (!active_edge[eid]) continue;
            ++st_.recursive_prefilter_edge_tests;
            if (local_edge_k2_certifies(L, active_edge, eid, x)) {
                active_edge[eid] = 0;
                ++st_.recursive_prefilter_edge_removals;
                changed = true;
            }
        }
    }

    // Forest-through-future is a visible certificate for vanishing H1 and H2.
    // The internal edge deletions used K=2 certificates inside L, hence preserve
    // H0,H1,H2 of the lower-link filtration over the future interval.
    bool ok = forest_future_connected_with_active_edges(L, active_edge, x);
    st_.recursive_prefilter_seconds += now_seconds() - t0;
    if (ok) ++st_.recursive_prefilter_success;
    else ++st_.recursive_prefilter_fail;
    return ok;
}


bool TrimEngine::k2_raw(EdgeId eid, LinkSummary* S) {
    auto const& e = G_.edge(eid);
    double build_seconds = 0.0;
    double reduction_seconds = 0.0;

    const double build0 = now_seconds();
    LowerLink2& L = build_lower_link_1_skeleton(eid);
    const double build1 = now_seconds();
    build_seconds += build1 - build0;
    st_.build_1_skeleton_seconds += build1 - build0;

    auto finish = [&](bool ok) {
        if (S) {
            S->vertices = static_cast<int>(L.V.size());
            S->edges = static_cast<int>(L.E.size());
            S->triangles = static_cast<int>(L.T.size());
            S->tetrahedra = 0;
            S->simplices = static_cast<int>(L.V.size() + L.E.size() + L.T.size());
        }
        st_.ph_lower_link_seconds += build_seconds;
        st_.ph_reduction_seconds += reduction_seconds;
        return ok;
    };

    const double h0_0 = now_seconds();
    bool h0_ok = lower_link_h0_future_connected(L, e.w);
    const double h0_1 = now_seconds();
    reduction_seconds += h0_1 - h0_0;
    st_.connectivity_seconds += h0_1 - h0_0;
    if (!h0_ok) return finish(false);

    const int cycle_rank = static_cast<int>(L.E.size()) - static_cast<int>(L.V.size()) + 1;
    if (cycle_rank <= 0) return finish(true);

    const double tri0 = now_seconds();
    build_lower_link_triangles(L);
    const double tri1 = now_seconds();
    build_seconds += tri1 - tri0;
    st_.build_triangles_seconds += tri1 - tri0;

    if (static_cast<int>(L.T.size()) < cycle_rank) return finish(false);

    if (opt_.k2_prefilter == K2PrefilterMode::RecursiveTrim) {
        if (recursive_trim_prefilter_forest(L, e.w)) return finish(true);
    }

    const double h1_0 = now_seconds();
    bool h1_ok = lower_link_h1_future_zero(L, e.w);
    const double h1_1 = now_seconds();
    reduction_seconds += h1_1 - h1_0;
    return finish(h1_ok);
}

bool TrimEngine::k3_raw(EdgeId eid, LinkSummary* S) {
    auto const& e = G_.edge(eid);
    double build_seconds = 0.0;
    double reduction_seconds = 0.0;

    const double build0 = now_seconds();
    LowerLink2& L = build_lower_link_1_skeleton(eid);
    const double build1 = now_seconds();
    build_seconds += build1 - build0;
    st_.build_1_skeleton_seconds += build1 - build0;

    auto finish = [&](bool ok) {
        if (S) {
            S->vertices = static_cast<int>(L.V.size());
            S->edges = static_cast<int>(L.E.size());
            S->triangles = static_cast<int>(L.T.size());
            S->tetrahedra = static_cast<int>(L.Q.size());
            S->simplices = static_cast<int>(L.V.size() + L.E.size() + L.T.size() + L.Q.size());
        }
        st_.ph_lower_link_seconds += build_seconds;
        st_.ph_reduction_seconds += reduction_seconds;
        return ok;
    };

    const double h0_0 = now_seconds();
    bool h0_ok = lower_link_h0_future_connected(L, e.w);
    const double h0_1 = now_seconds();
    reduction_seconds += h0_1 - h0_0;
    st_.connectivity_seconds += h0_1 - h0_0;
    if (!h0_ok) return finish(false);

    const int cycle_rank = static_cast<int>(L.E.size()) - static_cast<int>(L.V.size()) + 1;
    if (cycle_rank <= 0) return finish(true);

    const double tri0 = now_seconds();
    build_lower_link_triangles(L);
    const double tri1 = now_seconds();
    build_seconds += tri1 - tri0;
    st_.build_triangles_seconds += tri1 - tri0;

    if (static_cast<int>(L.T.size()) < cycle_rank) return finish(false);

    if (opt_.k3_mode != K3Mode::ExactRank) {
        if (recursive_trim_prefilter_forest_k2(L, e.w)) return finish(true);
        if (opt_.k3_mode == K3Mode::RecursiveOnly) return finish(false);
    }

    const double tet0 = now_seconds();
    build_lower_link_tetrahedra(L);
    const double tet1 = now_seconds();
    build_seconds += tet1 - tet0;
    st_.build_tetrahedra_seconds += tet1 - tet0;

    const double h2_0 = now_seconds();
    bool ok = lower_link_h2_future_zero(L, e.w);
    const double h2_1 = now_seconds();
    reduction_seconds += h2_1 - h2_0;
    return finish(ok);
}


bool TrimEngine::homology(EdgeId eid, LinkSummary* L) {
    double t0 = now_seconds();
    ++st_.ph_calls;
    LinkSummary loc;
    bool ok = false;
    if (opt_.max_global_dim == 0) ok = k0_raw(eid, &loc);
    else if (!opt_.force_general && opt_.max_global_dim == 1) ok = k1_raw(eid, &loc);
    else if (!opt_.force_general && opt_.max_global_dim == 2) ok = k2_raw(eid, &loc);
    else if (!opt_.force_general && opt_.max_global_dim == 3) ok = k3_raw(eid, &loc);
    else if (opt_.max_global_dim >= 1) {
        auto const& e = G_.edge(eid);
        GeneralLowerLink& gl = build_general_lower_link(eid);
        double fail_time = homology_failure_time_general(gl, e.w, opt_.max_global_dim);
        ok = std::isinf(fail_time);
        loc.vertices = gl.m();
        int total = gl.m();
        for (size_t d = 1; d < gl.levels.size(); ++d) total += static_cast<int>(gl.levels[d].size());
        if (gl.levels.size() > 1) loc.edges = static_cast<int>(gl.levels[1].size());
        if (gl.levels.size() > 2) loc.triangles = static_cast<int>(gl.levels[2].size());
        if (gl.levels.size() > 3) loc.tetrahedra = static_cast<int>(gl.levels[3].size());
        loc.simplices = total;
    } else {
        throw std::runtime_error("unsupported max_global_dim");
    }
    st_.ph_seconds += now_seconds() - t0;
    st_.observe_link(loc);
    if (L) *L = loc;
    if (ok) ++st_.ph_success; else ++st_.ph_fail;
    return ok;
}

} // namespace ht
