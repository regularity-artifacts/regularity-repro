#include "ht/io.hpp"

#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <utility>

namespace ht {

std::vector<Edge> read_edges(const std::string& path) {
    std::ifstream f(path);
    if (!f) throw std::runtime_error("cannot open input file: " + path);
    std::vector<Edge> es;
    std::string line;
    int line_no = 0;
    while (std::getline(f, line)) {
        ++line_no;
        auto p = line.find('#');
        if (p != std::string::npos) line = line.substr(0,p);
        std::istringstream iss(line);
        int u, v; double w;
        if (!(iss >> u >> v >> w)) continue;
        if (u < 0 || v < 0) throw std::runtime_error("negative vertex id at line " + std::to_string(line_no));
        if (u == v) continue;
        if (u > v) std::swap(u,v);
        es.push_back({u,v,w,true,-1});
    }
    return es;
}

std::string json_escape(const std::string& s) {
    std::ostringstream o;
    for (char c : s) {
        if (c == '"') o << "\\\"";
        else if (c == '\\') o << "\\\\";
        else if (c == '\n') o << "\\n";
        else if (c == '\r') o << "\\r";
        else if (c == '\t') o << "\\t";
        else o << c;
    }
    return o.str();
}

void write_report(const std::string& path, const Options& opt, const Stats& st) {
    std::ofstream f(path);
    if (!f) throw std::runtime_error("cannot open report file: " + path);
    auto avg = [](long long s, long long c){ return c ? double(s)/double(c) : 0.0; };
    f << std::setprecision(17);
    f << "{\n";
    f << "  \"max_global_dim\": " << opt.max_global_dim << ",\n";
    {
        std::string degs = "-1";
        for (int j = 0; j < opt.max_global_dim; ++j) degs += ", " + std::to_string(j);
        f << "  \"lower_link_checked_degrees\": [" << degs << "],\n";
    }
    f << "  \"oracle\": \"" << to_string(opt.oracle) << "\",\n";
    f << "  \"schedule\": \"" << to_string(opt.schedule) << "\",\n";
    f << "  \"order\": \"" << to_string(opt.order) << "\",\n";
    f << "  \"k2_prefilter\": \"" << to_string(opt.k2_prefilter) << "\",\n";
    f << "  \"k3_mode\": \"" << to_string(opt.k3_mode) << "\",\n";
    f << "  \"initial_edges\": " << st.initial_edges << ",\n";
    f << "  \"final_edges\": " << st.final_edges << ",\n";
    f << "  \"removed_count\": " << st.removed_count << ",\n";
    f << "  \"domination_removals\": " << st.domination_removals << ",\n";
    f << "  \"homology_removals\": " << st.homology_removals << ",\n";
    f << "  \"delayed_count\": " << st.delayed_count << ",\n";
    f << "  \"homology_delay_count\": " << st.homology_delay_count << ",\n";
    f << "  \"total_delay\": " << st.total_delay << ",\n";
    f << "  \"max_delay\": " << st.max_delay << ",\n";
    f << "  \"domination_calls\": " << st.domination_calls << ",\n";
    f << "  \"domination_success\": " << st.domination_success << ",\n";
    f << "  \"domination_fail\": " << st.domination_fail << ",\n";
    f << "  \"ph_calls\": " << st.ph_calls << ",\n";
    f << "  \"ph_success\": " << st.ph_success << ",\n";
    f << "  \"ph_fail\": " << st.ph_fail << ",\n";
    f << "  \"domination_seconds\": " << st.domination_seconds << ",\n";
    f << "  \"ph_seconds\": " << st.ph_seconds << ",\n";
    f << "  \"ph_lower_link_seconds\": " << st.ph_lower_link_seconds << ",\n";
    f << "  \"ph_reduction_seconds\": " << st.ph_reduction_seconds << ",\n";
    f << "  \"build_1_skeleton_seconds\": " << st.build_1_skeleton_seconds << ",\n";
    f << "  \"build_triangles_seconds\": " << st.build_triangles_seconds << ",\n";
    f << "  \"build_tetrahedra_seconds\": " << st.build_tetrahedra_seconds << ",\n";
    f << "  \"connectivity_seconds\": " << st.connectivity_seconds << ",\n";
    f << "  \"rank_boundary2_seconds\": " << st.rank_boundary2_seconds << ",\n";
    f << "  \"rank_boundary3_seconds\": " << st.rank_boundary3_seconds << ",\n";
    f << "  \"boundary2_columns\": " << st.boundary2_columns << ",\n";
    f << "  \"boundary3_columns\": " << st.boundary3_columns << ",\n";
    f << "  \"boundary2_rank_increments\": " << st.boundary2_rank_increments << ",\n";
    f << "  \"boundary3_rank_increments\": " << st.boundary3_rank_increments << ",\n";
    f << "  \"boundary2_xor_ops\": " << st.boundary2_xor_ops << ",\n";
    f << "  \"boundary3_xor_ops\": " << st.boundary3_xor_ops << ",\n";
    f << "  \"boundary3_feasibility_rejects\": " << st.boundary3_feasibility_rejects << ",\n";
    f << "  \"boundary3_skipped_after_zero\": " << st.boundary3_skipped_after_zero << ",\n";
    f << "  \"recursive_prefilter_calls\": " << st.recursive_prefilter_calls << ",\n";
    f << "  \"recursive_prefilter_success\": " << st.recursive_prefilter_success << ",\n";
    f << "  \"recursive_prefilter_fail\": " << st.recursive_prefilter_fail << ",\n";
    f << "  \"recursive_prefilter_edge_tests\": " << st.recursive_prefilter_edge_tests << ",\n";
    f << "  \"recursive_prefilter_edge_removals\": " << st.recursive_prefilter_edge_removals << ",\n";
    f << "  \"recursive_prefilter_seconds\": " << st.recursive_prefilter_seconds << ",\n";
    f << "  \"avg_ph_link_vertices\": " << avg(st.sum_link_vertices, st.ph_calls) << ",\n";
    f << "  \"avg_ph_link_edges\": " << avg(st.sum_link_edges, st.ph_calls) << ",\n";
    f << "  \"avg_ph_link_triangles\": " << avg(st.sum_link_triangles, st.ph_calls) << ",\n";
    f << "  \"avg_ph_link_tetrahedra\": " << avg(st.sum_link_tetrahedra, st.ph_calls) << ",\n";
    f << "  \"avg_ph_link_simplices\": " << avg(st.sum_link_simplices, st.ph_calls) << ",\n";
    f << "  \"max_ph_link_vertices\": " << st.max_link_vertices << ",\n";
    f << "  \"max_ph_link_edges\": " << st.max_link_edges << ",\n";
    f << "  \"max_ph_link_triangles\": " << st.max_link_triangles << ",\n";
    f << "  \"max_ph_link_tetrahedra\": " << st.max_link_tetrahedra << ",\n";
    f << "  \"max_ph_link_simplices\": " << st.max_link_simplices << ",\n";
    f << "  \"removed_edges\": [\n";
    for (size_t i=0;i<st.removed_edges.size();++i) {
        auto const& r = st.removed_edges[i];
        f << "    {\"u\": " << r.u << ", \"v\": " << r.v << ", \"w\": " << r.w
          << ", \"new_w\": " << r.new_w
          << ", \"action\": \"" << json_escape(r.action) << "\""
          << ", \"phase\": \"" << json_escape(r.phase) << "\", \"pass\": " << r.pass
          << ", \"oracle\": \"" << json_escape(r.oracle) << "\", \"apex\": " << r.apex
          << ", \"lower_link_vertices\": " << r.link.vertices
          << ", \"lower_link_edges\": " << r.link.edges
          << ", \"lower_link_triangles\": " << r.link.triangles
          << ", \"lower_link_tetrahedra\": " << r.link.tetrahedra
          << ", \"lower_link_simplices\": " << r.link.simplices << "}";
        if (i + 1 < st.removed_edges.size()) f << ",";
        f << "\n";
    }
    f << "  ]\n}\n";
}

void usage() {
    std::cerr << "Usage:\n  ht_trim input_edges.txt output_edges.txt [options]\n\n"
              << "Options:\n"
              << "  --max-global-dim K      Any K>=0. K=0,1,2 production; K=3 hand-specialized; K>=4 general staged rank-sweep. Default: 1\n"
              << "  --oracle MODE           domination | homology | hybrid | gudhi-collapse | homology-delay | hybrid-delay. Default: hybrid\n"
              << "  --schedule MODE         staged | interleaved. Default: staged\n"
              << "  --order MODE            reverse | forward | lex. Default: reverse\n"
              << "  --k2-prefilter MODE     none | recursive-trim. Default: none\n"
              << "  --k3-mode MODE          exact-rank | recursive-prefilter | recursive-only. Default: exact-rank\n"
              << "  --report PATH           Write JSON report.\n"
              << "  --no-certificate        Do not list every removed edge.\n";
}

} // namespace ht
