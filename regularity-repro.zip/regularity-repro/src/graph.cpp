#include "ht/graph.hpp"

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <limits>
#include <map>
#include <set>
#include <stdexcept>

namespace ht {

WeightedGraph::WeightedGraph(const std::vector<Edge>& input) { build(input); }

void WeightedGraph::build(const std::vector<Edge>& input) {
    int maxv = -1;
    std::map<std::pair<int, int>, double> best;

    for (auto e : input) {
        if (e.u == e.v) continue;
        if (e.u > e.v) std::swap(e.u, e.v);
        maxv = std::max(maxv, std::max(e.u, e.v));
        auto k = std::make_pair(e.u, e.v);
        auto it = best.find(k);
        if (it == best.end() || e.w < it->second) best[k] = e.w;
    }

    n_ = maxv + 1;
    edges_.clear();
    edges_.reserve(best.size());
    adj_.assign(n_, {});
    lookup_.clear();
    lookup_.reserve(best.size() * 2);

    for (auto const& kv : best) {
        Edge e;
        e.u = kv.first.first;
        e.v = kv.first.second;
        e.w = kv.second;
        e.active = true;
        e.id = static_cast<EdgeId>(edges_.size());
        edges_.push_back(e);
        adj_[e.u].push_back({e.v, e.id});
        adj_[e.v].push_back({e.u, e.id});
        lookup_[key_edge(e.u, e.v)] = e.id;
    }

    for (auto& nbrs : adj_) {
        std::sort(nbrs.begin(), nbrs.end(), [](AdjEntry const& a, AdjEntry const& b) {
            return a.nbr < b.nbr;
        });
    }
}

const Edge& WeightedGraph::edge(EdgeId id) const { return edges_.at(id); }

bool WeightedGraph::active(EdgeId id) const {
    return id >= 0 && id < static_cast<int>(edges_.size()) && edges_[id].active;
}

EdgeId WeightedGraph::edge_id(int u, int v) const {
    auto it = lookup_.find(key_edge(u, v));
    if (it == lookup_.end()) return -1;
    return it->second;
}

bool WeightedGraph::has_active_edge(int u, int v) const {
    return active(edge_id(u, v));
}

double WeightedGraph::weight(int u, int v) const {
    EdgeId id = edge_id(u, v);
    if (id < 0) return std::numeric_limits<double>::infinity();
    return edges_[id].w;
}

bool WeightedGraph::active_weight(int u, int v, double* w) const {
    EdgeId id = edge_id(u, v);
    if (id < 0 || !edges_[id].active) return false;
    if (w) *w = edges_[id].w;
    return true;
}

void WeightedGraph::deactivate(EdgeId id) {
    if (active(id)) edges_[id].active = false;
}

void WeightedGraph::set_weight(EdgeId id, double w) {
    if (id < 0 || id >= static_cast<int>(edges_.size())) return;
    edges_[id].w = w;
}

int WeightedGraph::active_edge_count() const {
    int c = 0;
    for (auto const& e : edges_) if (e.active) ++c;
    return c;
}

std::vector<EdgeId> WeightedGraph::active_edge_ids() const {
    std::vector<EdgeId> ids;
    ids.reserve(edges_.size());
    for (auto const& e : edges_) if (e.active) ids.push_back(e.id);
    return ids;
}

std::vector<int> WeightedGraph::active_neighbors(int u) const {
    std::vector<int> out;
    if (u < 0 || u >= n_) return out;
    for (AdjEntry const& a : adj_[u]) {
        auto const& e = edges_[a.eid];
        if (!e.active) continue;
        out.push_back(a.nbr);
    }
    return out;
}

std::vector<int> WeightedGraph::active_common_neighbors(int u, int v) const {
    std::vector<int> common;
    std::vector<double> alpha;
    active_common_neighbors_with_alpha(u, v, common, alpha);
    return common;
}

void WeightedGraph::active_common_neighbors_with_alpha(int u, int v,
                                                       std::vector<int>& common,
                                                       std::vector<double>& alpha) const {
    common.clear();
    alpha.clear();
    if (u < 0 || v < 0 || u >= n_ || v >= n_) return;

    auto const& Nu = adj_[u];
    auto const& Nv = adj_[v];
    size_t i = 0, j = 0;
    while (i < Nu.size() && j < Nv.size()) {
        int a = Nu[i].nbr;
        int b = Nv[j].nbr;
        if (a < b) { ++i; continue; }
        if (b < a) { ++j; continue; }

        int q = a;
        if (q != u && q != v) {
            auto const& eu = edges_[Nu[i].eid];
            auto const& ev = edges_[Nv[j].eid];
            if (eu.active && ev.active) {
                common.push_back(q);
                alpha.push_back(std::max(eu.w, ev.w));
            }
        }
        ++i;
        ++j;
    }
}

bool WeightedGraph::active_neighbors_cover_bounds(int c,
                                                  const std::vector<int>& common,
                                                  const std::vector<double>& alpha,
                                                  int skip_index) const {
    if (c < 0 || c >= n_) return false;
    auto const& Nc = adj_[c];
    size_t p = 0;

    for (int i = 0; i < static_cast<int>(common.size()); ++i) {
        if (i == skip_index) continue;
        int q = common[static_cast<size_t>(i)];
        if (q == c) continue;

        while (p < Nc.size() && Nc[p].nbr < q) ++p;
        if (p >= Nc.size() || Nc[p].nbr != q) return false;

        auto const& e = edges_[Nc[p].eid];
        if (!e.active) return false;
        if (e.w > alpha[static_cast<size_t>(i)] + EPS) return false;
    }
    return true;
}

void WeightedGraph::write_active_edges(const std::string& path) const {
    std::ofstream f(path);
    if (!f) throw std::runtime_error("cannot open output file: " + path);
    f << std::setprecision(17);
    std::vector<Edge> es;
    for (auto const& e : edges_) if (e.active) es.push_back(e);
    std::sort(es.begin(), es.end(), [](auto const& a, auto const& b) {
        if (a.u != b.u) return a.u < b.u;
        return a.v < b.v;
    });
    for (auto const& e : es) f << e.u << " " << e.v << " " << e.w << "\n";
}

} // namespace ht
