#include "ht/trim_engine.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace ht {

TrimEngine::TrimEngine(WeightedGraph G, Options opt): G_(std::move(G)), opt_(opt) {
    if (opt_.max_global_dim < 0) {
        throw std::runtime_error("--max-global-dim must be >= 0");
    }
    st_.initial_edges = G_.active_edge_count();
}

Stats TrimEngine::run() {
    if (opt_.oracle == OracleMode::GudhiCollapse) {
        run_gudhi_collapse();
    } else if (opt_.oracle == OracleMode::HomologyDelay) {
        run_homology_delay_until_stable();
    } else if (opt_.oracle == OracleMode::HybridDelay) {
        // Experimental delay-aware hybrid: first apply the GUDHI-style
        // domination-delay/collapse baseline, then run homology-certified
        // delay/deletion to saturation.  These operations are deliberately
        // recorded as a separate oracle mode; pure deletion modes are unchanged.
        run_gudhi_collapse();
        run_homology_delay_until_stable();
    } else if (opt_.schedule == ScheduleMode::Staged) {
        run_staged();
    } else {
        run_interleaved();
    }
    st_.final_edges = G_.active_edge_count();
    st_.removed_count = st_.initial_edges - st_.final_edges;
    return st_;
}

std::vector<EdgeId> TrimEngine::active_edges_in_order() const {
    auto ids = G_.active_edge_ids();
    std::sort(ids.begin(), ids.end(), [&](EdgeId a, EdgeId b){
        auto const& A = G_.edge(a); auto const& B = G_.edge(b);
        if (opt_.order == OrderMode::Lex) {
            if (A.u != B.u) return A.u < B.u;
            return A.v < B.v;
        }
        if (std::abs(A.w - B.w) > EPS) {
            if (opt_.order == OrderMode::Forward) return A.w < B.w;
            return A.w > B.w;
        }
        if (A.u != B.u) return A.u < B.u;
        return A.v < B.v;
    });
    return ids;
}

void TrimEngine::remove_record(EdgeId eid, std::string phase, int pass, std::string oracle, int apex, LinkSummary L) {
    auto e = G_.edge(eid);
    if (opt_.certificate) {
        RemovedRecord r;
        r.u = e.u; r.v = e.v; r.apex = apex; r.pass = pass;
        r.w = e.w; r.new_w = e.w; r.phase = phase; r.oracle = oracle;
        r.action = "remove"; r.link = L;
        st_.removed_edges.push_back(r);
    }
    G_.deactivate(eid);
    if (oracle == "domination") ++st_.domination_removals;
    else ++st_.homology_removals;
}

void TrimEngine::delay_record(EdgeId eid, double new_weight, std::string phase, int pass, std::string oracle, LinkSummary L) {
    auto e = G_.edge(eid);
    if (new_weight <= e.w + EPS) return;
    if (opt_.certificate) {
        RemovedRecord r;
        r.u = e.u; r.v = e.v; r.apex = -1; r.pass = pass;
        r.w = e.w; r.new_w = new_weight; r.phase = phase; r.oracle = oracle;
        r.action = "delay"; r.link = L;
        st_.removed_edges.push_back(r);
    }
    st_.delayed_count += 1;
    if (oracle.find("homology") != std::string::npos) st_.homology_delay_count += 1;
    st_.total_delay += new_weight - e.w;
    st_.max_delay = std::max(st_.max_delay, new_weight - e.w);
    G_.set_weight(eid, new_weight);
}

void TrimEngine::run_domination_until_stable() {
    bool changed=true; int pass=0;
    while (changed) {
        changed=false; ++pass;
        for (EdgeId eid : active_edges_in_order()) {
            if (!G_.active(eid)) continue;
            int apex=-1;
            if (domination(eid,&apex)) { remove_record(eid,"D",pass,"domination",apex,{}); changed=true; }
        }
    }
}

void TrimEngine::run_homology_until_stable() {
    bool changed=true; int pass=0;
    while (changed) {
        changed=false; ++pass;
        for (EdgeId eid : active_edges_in_order()) {
            if (!G_.active(eid)) continue;
            if (opt_.oracle == OracleMode::Hybrid) {
                int apex=-1;
                if (domination(eid,&apex)) { remove_record(eid,"H",pass,"domination",apex,{}); changed=true; continue; }
            }
            LinkSummary L;
            if (homology(eid,&L)) { remove_record(eid,"H",pass,"homology",-1,L); changed=true; }
        }
    }
}

void TrimEngine::run_homology_delay_until_stable() {
    bool changed = true;
    int pass = 0;
    while (changed) {
        changed = false;
        ++pass;
        for (EdgeId eid : active_edges_in_order()) {
            if (!G_.active(eid)) continue;
            DelayDecision d = homology_delay_decision(eid);
            st_.observe_link(d.link);
            if (d.action == DelayAction::Delete) {
                remove_record(eid, "HD", pass, "homology-delay", -1, d.link);
                changed = true;
            } else if (d.action == DelayAction::Delay) {
                delay_record(eid, d.new_weight, "HD", pass, "homology-delay", d.link);
                changed = true;
            }
        }
    }
}

void TrimEngine::run_staged() {
    if (opt_.oracle == OracleMode::Domination || opt_.oracle == OracleMode::Hybrid) run_domination_until_stable();
    if (opt_.oracle == OracleMode::Homology || opt_.oracle == OracleMode::Hybrid) run_homology_until_stable();
}

void TrimEngine::run_interleaved() {
    bool changed=true; int pass=0;
    while (changed) {
        changed=false; ++pass;
        for (EdgeId eid : active_edges_in_order()) {
            if (!G_.active(eid)) continue;
            if (opt_.oracle == OracleMode::Domination || opt_.oracle == OracleMode::Hybrid) {
                int apex=-1;
                if (domination(eid,&apex)) { remove_record(eid,"I",pass,"domination",apex,{}); changed=true; continue; }
            }
            if (opt_.oracle == OracleMode::Homology || opt_.oracle == OracleMode::Hybrid) {
                LinkSummary L;
                if (homology(eid,&L)) { remove_record(eid,"I",pass,"homology",-1,L); changed=true; continue; }
            }
        }
    }
}

} // namespace ht
