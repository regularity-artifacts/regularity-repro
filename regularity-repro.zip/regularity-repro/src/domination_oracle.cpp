#include "ht/trim_engine.hpp"
#include <algorithm>

namespace ht {



bool TrimEngine::domination_raw(EdgeId eid, int* apex_out) const {
    auto const& e = G_.edge(eid);

    // Fast, allocation-light version of the conical lower-link test.
    //
    // For the edge e={u,v}, the lower-link vertices are common active
    // neighbors q with birth alpha(q)=max(w(u,q),w(v,q)).  The edge is
    // deletion-dominated if some common neighbor c is already present at
    // w(e), i.e. alpha(c)<=w(e), and every lower-link vertex q is connected
    // to c by time alpha(q).  This is exactly the pure deletion certificate;
    // no filtration delays or non-certified shortcuts are used here.
    std::vector<int> common;
    std::vector<double> alpha;
    G_.active_common_neighbors_with_alpha(e.u, e.v, common, alpha);
    if (common.empty()) return false;

    for (int ci = 0; ci < static_cast<int>(common.size()); ++ci) {
        int c = common[static_cast<size_t>(ci)];
        if (alpha[static_cast<size_t>(ci)] > e.w + EPS) continue;
        if (G_.active_neighbors_cover_bounds(c, common, alpha, ci)) {
            if (apex_out) *apex_out = c;
            return true;
        }
    }
    return false;
}

bool TrimEngine::domination(EdgeId eid, int* apex_out) {
    double t0 = now_seconds();
    ++st_.domination_calls;
    bool ok = domination_raw(eid, apex_out);
    st_.domination_seconds += now_seconds() - t0;
    if (ok) ++st_.domination_success; else ++st_.domination_fail;
    return ok;
}

} // namespace ht
