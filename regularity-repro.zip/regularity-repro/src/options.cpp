#include "ht/options.hpp"

namespace ht {

std::string to_string(OracleMode x) {
    if (x == OracleMode::Domination) return "domination";
    if (x == OracleMode::Homology) return "homology";
    if (x == OracleMode::Hybrid) return "hybrid";
    if (x == OracleMode::GudhiCollapse) return "gudhi-collapse";
    if (x == OracleMode::HomologyDelay) return "homology-delay";
    if (x == OracleMode::HybridDelay) return "hybrid-delay";
    return "unknown";
}

std::string to_string(ScheduleMode x) {
    return x == ScheduleMode::Interleaved ? "interleaved" : "staged";
}

std::string to_string(OrderMode x) {
    return x == OrderMode::Forward ? "forward" :
           x == OrderMode::Lex ? "lex" : "reverse";
}

std::string to_string(K2PrefilterMode x) {
    return x == K2PrefilterMode::RecursiveTrim ? "recursive-trim" : "none";
}

std::string to_string(K3Mode x) {
    if (x == K3Mode::RecursivePrefilter) return "recursive-prefilter";
    if (x == K3Mode::RecursiveOnly) return "recursive-only";
    return "exact-rank";
}

OracleMode parse_oracle(const std::string& s) {
    if (s == "domination") return OracleMode::Domination;
    if (s == "homology") return OracleMode::Homology;
    if (s == "hybrid") return OracleMode::Hybrid;
    if (s == "gudhi-collapse" || s == "gudhi" || s == "edge-collapse" || s == "domination-delay") return OracleMode::GudhiCollapse;
    if (s == "homology-delay" || s == "hdelay") return OracleMode::HomologyDelay;
    if (s == "hybrid-delay" || s == "delay-hybrid") return OracleMode::HybridDelay;
    throw std::runtime_error("unknown --oracle " + s);
}

ScheduleMode parse_schedule(const std::string& s) {
    if (s == "staged") return ScheduleMode::Staged;
    if (s == "interleaved") return ScheduleMode::Interleaved;
    throw std::runtime_error("unknown --schedule " + s);
}

OrderMode parse_order(const std::string& s) {
    if (s == "reverse") return OrderMode::Reverse;
    if (s == "forward") return OrderMode::Forward;
    if (s == "lex") return OrderMode::Lex;
    throw std::runtime_error("unknown --order " + s);
}

K2PrefilterMode parse_k2_prefilter(const std::string& s) {
    if (s == "none") return K2PrefilterMode::None;
    if (s == "recursive-trim" || s == "recursive") return K2PrefilterMode::RecursiveTrim;
    throw std::runtime_error("unknown --k2-prefilter " + s);
}

K3Mode parse_k3_mode(const std::string& s) {
    if (s == "exact-rank" || s == "exact") return K3Mode::ExactRank;
    if (s == "recursive-prefilter" || s == "recursive") return K3Mode::RecursivePrefilter;
    if (s == "recursive-only") return K3Mode::RecursiveOnly;
    throw std::runtime_error("unknown --k3-mode " + s);
}

} // namespace ht
