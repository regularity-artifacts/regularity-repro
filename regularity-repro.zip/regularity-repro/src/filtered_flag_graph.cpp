#include "ht/filtered_flag_graph.hpp"

namespace ht {

void FilteredFlagGraph::clear() {
    V.clear();
    E.clear();
    T.clear();
    Q.clear();
    edge_id.clear();
    triangle_id.clear();
}

void FilteredFlagGraph::init_edge_lookup(int m) {
    edge_id.assign(static_cast<size_t>(m) * static_cast<size_t>(m), -1);
}

void FilteredFlagGraph::init_triangle_lookup(int m) {
    triangle_id.assign(static_cast<size_t>(m) * static_cast<size_t>(m) * static_cast<size_t>(m), -1);
}

int FilteredFlagGraph::lookup_index(int i, int j) const {
    const int m = static_cast<int>(V.size());
    return i * m + j;
}

int FilteredFlagGraph::triangle_lookup_index(int i, int j, int k) const {
    std::array<int,3> a{i, j, k};
    std::sort(a.begin(), a.end());
    const int m = static_cast<int>(V.size());
    return (a[0] * m + a[1]) * m + a[2];
}

int FilteredFlagGraph::local_edge_id(int i, int j) const {
    if (i < 0 || j < 0) return -1;
    const int m = static_cast<int>(V.size());
    if (i >= m || j >= m) return -1;
    if (edge_id.empty()) return -1;
    return edge_id[lookup_index(i, j)];
}

int FilteredFlagGraph::local_triangle_id(int i, int j, int k) const {
    if (i < 0 || j < 0 || k < 0) return -1;
    const int m = static_cast<int>(V.size());
    if (i >= m || j >= m || k >= m) return -1;
    if (triangle_id.empty()) return -1;
    return triangle_id[triangle_lookup_index(i, j, k)];
}

void FilteredFlagGraph::set_local_edge_id(int i, int j, int id) {
    if (edge_id.empty()) init_edge_lookup(static_cast<int>(V.size()));
    edge_id[lookup_index(i, j)] = id;
    edge_id[lookup_index(j, i)] = id;
}

void FilteredFlagGraph::set_local_triangle_id(int i, int j, int k, int id) {
    if (triangle_id.empty()) init_triangle_lookup(static_cast<int>(V.size()));
    triangle_id[triangle_lookup_index(i, j, k)] = id;
}

} // namespace ht
