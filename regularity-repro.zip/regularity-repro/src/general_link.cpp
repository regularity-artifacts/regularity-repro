#include "ht/general_link.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace ht {

namespace {
constexpr double NAN_D = std::numeric_limits<double>::quiet_NaN();
inline bool is_absent(double b) { return std::isnan(b); }
} // namespace

void GeneralLowerLink::reset(int m) {
    m_ = m;
    words_ = (m + 63) / 64;
    if (words_ == 0) words_ = 1;

    alpha.assign(static_cast<size_t>(m), 0.0);
    q.assign(static_cast<size_t>(m), -1);

    beta_.assign(static_cast<size_t>(m) * static_cast<size_t>(m), NAN_D);
    nbr_bits_.assign(static_cast<size_t>(m) * static_cast<size_t>(words_), 0ULL);

    levels.clear();
    levels.resize(2); // levels[0] unused, levels[1] = edges (built lazily)
    index_maps_.clear();
    index_maps_.resize(2);
    built_dim_ = 0;
}

void GeneralLowerLink::set_edge(int i, int j, double b) {
    if (i > j) std::swap(i, j);
    beta_[static_cast<size_t>(i) * m_ + j] = b;
    beta_[static_cast<size_t>(j) * m_ + i] = b;
    nbr_mut(i)[j >> 6] |= (1ULL << (j & 63));
    nbr_mut(j)[i >> 6] |= (1ULL << (i & 63));
}

bool GeneralLowerLink::has_edge(int i, int j) const {
    return !is_absent(beta_[static_cast<size_t>(i) * m_ + j]);
}

double GeneralLowerLink::beta(int i, int j) const {
    return beta_[static_cast<size_t>(i) * m_ + j];
}

uint64_t GeneralLowerLink::pack(std::vector<int> const& verts) const {
    uint64_t k = 0;
    const uint64_t base = static_cast<uint64_t>(m_) + 1;
    for (int v : verts) k = k * base + static_cast<uint64_t>(v + 1);
    return k;
}

int GeneralLowerLink::index_of(int dim, std::vector<int> const& verts) const {
    if (dim < 0 || dim >= static_cast<int>(index_maps_.size())) return -1;
    auto it = index_maps_[dim].find(pack(verts));
    if (it == index_maps_[dim].end()) return -1;
    return it->second;
}

void GeneralLowerLink::ensure_levels(int target_dim) {
    if (target_dim <= built_dim_) return;
    if (target_dim >= static_cast<int>(levels.size())) {
        levels.resize(target_dim + 1);
        index_maps_.resize(target_dim + 1);
    }

    if (built_dim_ < 1) {
        auto& E = levels[1];
        E.clear();
        index_maps_[1].clear();
        for (int i = 0; i < m_; ++i) {
            const uint64_t* bi = nbr(i);
            for (int w = i >> 6; w < words_; ++w) {
                uint64_t bits = bi[w];
                if (w == (i >> 6)) {
                    // clear bits <= i within this word
                    int lowbit = i & 63;
                    if (lowbit == 63) continue;
                    bits &= ~((1ULL << (lowbit + 1)) - 1);
                }
                while (bits) {
                    int b = __builtin_ctzll(bits);
                    bits &= bits - 1;
                    int j = (w << 6) + b;
                    int idx = static_cast<int>(E.size());
                    E.push_back({{i, j}, beta(i, j)});
                    index_maps_[1].emplace(pack(E.back().verts), idx);
                }
            }
        }
        built_dim_ = 1;
    }

    std::vector<uint64_t> cand(words_);
    for (int d = built_dim_ + 1; d <= target_dim; ++d) {
        auto const& prev = levels[d - 1];
        auto& cur = levels[d];
        cur.clear();
        index_maps_[d].clear();

        for (auto const& s : prev) {
            // candidates = AND of neighbor bitsets of every vertex in s,
            // restricted to ids strictly greater than the last (largest) one.
            const int last = s.verts.back();
            std::fill(cand.begin(), cand.end(), ~0ULL);
            for (int v : s.verts) {
                const uint64_t* nv = nbr(v);
                for (int w = 0; w < words_; ++w) cand[w] &= nv[w];
            }
            {
                int lw = last >> 6;
                int lb = last & 63;
                for (int w = 0; w < lw; ++w) cand[w] = 0ULL;
                if (lw < words_) {
                    if (lb == 63) cand[lw] = 0ULL;
                    else cand[lw] &= ~((1ULL << (lb + 1)) - 1);
                }
            }

            for (int w = 0; w < words_; ++w) {
                uint64_t bits = cand[w];
                while (bits) {
                    int b = __builtin_ctzll(bits);
                    bits &= bits - 1;
                    int nv = (w << 6) + b;
                    std::vector<int> verts = s.verts;
                    verts.push_back(nv);
                    double birth = s.birth;
                    for (int v : s.verts) birth = std::max(birth, beta(v, nv));
                    int idx = static_cast<int>(cur.size());
                    cur.push_back({std::move(verts), birth});
                    index_maps_[d].emplace(pack(cur.back().verts), idx);
                }
            }
        }
        built_dim_ = d;
    }
}

} // namespace ht
