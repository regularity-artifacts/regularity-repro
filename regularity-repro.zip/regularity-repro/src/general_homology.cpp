#include "ht/trim_engine.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <numeric>

namespace ht {

namespace {
constexpr double INF_D = std::numeric_limits<double>::infinity();
}

GeneralLowerLink& TrimEngine::build_general_lower_link(EdgeId eid) const {
    auto const& e = G_.edge(eid);

    std::vector<int> common;
    std::vector<double> alpha;
    G_.active_common_neighbors_with_alpha(e.u, e.v, common, alpha);

    GeneralLowerLink& L = scratch_general_link_;
    const int m = static_cast<int>(common.size());
    L.reset(m);
    for (int i = 0; i < m; ++i) {
        L.q[i] = common[i];
        L.alpha[i] = alpha[i];
    }
    for (int i = 0; i < m; ++i) {
        for (int j = i + 1; j < m; ++j) {
            double wij;
            if (!G_.active_weight(common[i], common[j], &wij)) continue;
            double b = std::max({alpha[i], alpha[j], wij});
            L.set_edge(i, j, b);
        }
    }
    return L;
}

bool TrimEngine::insert_boundary_column_general(std::vector<int> col, std::vector<std::vector<int>>& basis) {
    ++st_.boundary_general_columns;
    std::sort(col.begin(), col.end());
    col.erase(std::unique(col.begin(), col.end()), col.end());

    while (!col.empty()) {
        int pivot = col.back();
        if (basis[pivot].empty()) {
            basis[pivot] = std::move(col);
            ++st_.boundary_general_rank_increments;
            return true;
        }
        ++st_.boundary_general_xor_ops;
        xor_sorted_inplace(col, basis[pivot]);
    }
    return false;
}

// Generalizes lower_link_h0/h1/h2_future_zero and first_h0/h1/h2_failure_time
// into a single staged sweep valid for any K>=1.
//
// IMPORTANT correctness note: beta_0, beta_1, ..., beta_{K-1} are
// independent conditions on the same filtered complex. A HIGHER-index Betti
// number can fail at an EARLIER time than a lower one (e.g. not enough
// triangles to kill a 1-cycle can happen well before the lower link even
// becomes disconnected). So no stage is allowed to return the moment it
// finds its own failure and stop the whole computation there -- that would
// silently miss an earlier failure a later stage might find using data
// available before that point. Instead every stage records its own first
// failure time (or +inf) into a running `best` (the tightest upper bound on
// the true answer found so far) and keeps feeding forward only the
// checkpoints that occur before `best`, so later stages both stay correct
// (they can only ever improve `best`, never miss something earlier) and
// stay cheap (nothing at or after the current best bound is ever explored).
//
// Stage 1 sweeps vertices+edges (DSU), and records, at every event time t,
// required[2](t) = dim Z_1(t) = (#active edges) - (#active vertices) +
// (#components) -- the boundary_2 rank a triangle sweep would need to
// supply to kill beta_1 at that time. This formula is valid regardless of
// whether beta_0 itself already failed by t (rank of a graph's ∂_1 is
// always vertices-minus-components).
//
// Stage d (2<=d<=K) only runs while some retained snapshot has a nonzero
// required rank (if it's always zero, no d-simplex can exist at all within
// that window -- a d-simplex's own boundary is always a live (d-1)-cycle,
// so Z_{d-1}=0 forever forces the d-skeleton to be empty forever, and
// success cascades through every remaining stage for free within that
// window). Otherwise it builds level d, sweeps its simplices merged with
// the inherited checkpoints (a d-simplex's birth need not coincide with any
// (d-1)-skeleton event, so the two event streams must be merged rather than
// checked only at the coarser inherited times), and produces required[d+1]
// snapshots for the next stage.
double TrimEngine::homology_failure_time_general(GeneralLowerLink& L, double x, int K) {
    const int m = L.m();
    struct Snap { double t; int required; };

    if (m == 0) return x;

    std::vector<int> vo(m);
    std::iota(vo.begin(), vo.end(), 0);
    std::sort(vo.begin(), vo.end(), [&](int a, int b) {
        if (std::abs(L.alpha[a] - L.alpha[b]) > EPS) return L.alpha[a] < L.alpha[b];
        return a < b;
    });

    L.ensure_levels(1);
    auto const& E = L.levels[1];
    std::vector<int> eo(E.size());
    std::iota(eo.begin(), eo.end(), 0);
    std::sort(eo.begin(), eo.end(), [&](int a, int b) {
        if (std::abs(E[a].birth - E[b].birth) > EPS) return E[a].birth < E[b].birth;
        return E[a].verts < E[b].verts;
    });

    DSU dsu(m);
    std::vector<char> active(m, 0);
    int active_vertices = 0, active_edges = 0, components = 0;

    auto add_vertex = [&](int i) {
        if (!active[i]) { active[i] = 1; ++active_vertices; ++components; }
    };
    auto add_edge = [&](int id) {
        auto const& e = E[id];
        ++active_edges;
        if (active[e.verts[0]] && active[e.verts[1]] && dsu.unite(e.verts[0], e.verts[1])) --components;
    };

    std::vector<Snap> snaps;
    size_t vi = 0, ei = 0;
    auto add_upto = [&](double t) {
        while (vi < vo.size() && L.alpha[vo[vi]] <= t + EPS) add_vertex(vo[vi++]);
        while (ei < eo.size() && E[eo[ei]].birth <= t + EPS) add_edge(eo[ei++]);
    };
    auto ok0 = [&]() { return active_vertices > 0 && components == 1; };

    double best = INF_D;
    add_upto(x);
    if (!ok0()) {
        best = x;
    } else {
        snaps.push_back({x, active_edges - active_vertices + components});
        while (vi < vo.size() || ei < eo.size()) {
            double t = INF_D;
            if (vi < vo.size()) t = std::min(t, L.alpha[vo[vi]]);
            if (ei < eo.size()) t = std::min(t, E[eo[ei]].birth);
            add_upto(t);
            if (!ok0()) { best = t; break; }
            snaps.push_back({t, active_edges - active_vertices + components});
        }
    }

    for (int d = 2; d <= K && !snaps.empty(); ++d) {
        // Anything at or after the current best bound cannot improve it.
        while (!snaps.empty() && snaps.back().t > best + EPS) snaps.pop_back();
        if (snaps.empty()) break;

        int max_required = 0;
        for (auto const& s : snaps) max_required = std::max(max_required, s.required);
        if (max_required == 0) break; // cascades: no d..K-skeleton can exist within [x,best)

        L.ensure_levels(d);
        auto const& Sd = L.levels[d];

        std::vector<int> so(Sd.size());
        std::iota(so.begin(), so.end(), 0);
        std::sort(so.begin(), so.end(), [&](int a, int b) {
            if (std::abs(Sd[a].birth - Sd[b].birth) > EPS) return Sd[a].birth < Sd[b].birth;
            return Sd[a].verts < Sd[b].verts;
        });

        auto const& Sd1 = L.levels[d - 1];
        std::vector<std::vector<int>> basis(Sd1.size());
        int rank_d = 0;
        size_t added = 0;   // index into so: d-simplices inserted into the boundary basis so far
        size_t si = 0;      // index into snaps: required-rank updates consumed so far
        int current_required = 0;

        auto add_simplex = [&](int id) {
            auto const& s = Sd[id];
            std::vector<int> facets;
            facets.reserve(s.verts.size());
            std::vector<int> f;
            f.reserve(s.verts.size() - 1);
            for (size_t k = 0; k < s.verts.size(); ++k) {
                f.clear();
                for (size_t t2 = 0; t2 < s.verts.size(); ++t2) {
                    if (t2 != k) f.push_back(s.verts[t2]);
                }
                int fidx = L.index_of(d - 1, f);
                if (fidx < 0) return; // malformed; should not happen
                facets.push_back(fidx);
            }
            const double r0 = now_seconds();
            bool inc = insert_boundary_column_general(std::move(facets), basis);
            st_.rank_boundary_general_seconds += now_seconds() - r0;
            if (inc) ++rank_d;
        };

        auto consume_upto = [&](double t) {
            while (si < snaps.size() && snaps[si].t <= t + EPS) {
                current_required = snaps[si].required;
                ++si;
            }
            while (added < so.size() && Sd[so[added]].birth <= t + EPS) {
                add_simplex(so[added]);
                ++added;
            }
        };

        std::vector<Snap> next_snaps;
        next_snaps.reserve(snaps.size() + so.size());
        double stage_fail = INF_D;

        consume_upto(x);
        if (static_cast<int>(added) < current_required) {
            ++st_.boundary_general_feasibility_rejects;
            stage_fail = x;
        } else if (rank_d != current_required) {
            stage_fail = x;
        } else {
            if (d < K) next_snaps.push_back({x, static_cast<int>(added) - rank_d});
            while (si < snaps.size() || added < so.size()) {
                double t = INF_D;
                if (si < snaps.size()) t = std::min(t, snaps[si].t);
                if (added < so.size()) t = std::min(t, Sd[so[added]].birth);
                if (t > best + EPS) break; // beyond current best bound: cannot help
                consume_upto(t);
                if (static_cast<int>(added) < current_required) {
                    ++st_.boundary_general_feasibility_rejects;
                    stage_fail = t;
                    break;
                }
                if (rank_d != current_required) { stage_fail = t; break; }
                if (d < K) next_snaps.push_back({t, static_cast<int>(added) - rank_d});
            }
        }

        if (stage_fail < best) best = stage_fail;
        snaps = std::move(next_snaps);
    }
    return best;
}

} // namespace ht
