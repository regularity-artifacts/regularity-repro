#!/usr/bin/env python3
"""
Basic tests for the C++ K=0/K=1/K=2 and experimental K=3 trim engine.

Run:
    python3 test_ht_trim_k012.py
"""

from __future__ import annotations

import itertools
import json
import math
import random
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "ht_trim"
EPS = 1e-9


def compile_cpp():
    subprocess.run(["make"], cwd=ROOT, check=True)


def run_trim(edge_text: str, *, K=1, oracle="hybrid", schedule="staged", order="reverse"):
    with tempfile.TemporaryDirectory() as td_s:
        td = Path(td_s)
        inp = td / "in_edges.txt"
        out = td / "out_edges.txt"
        rep = td / "report.json"
        inp.write_text(edge_text.strip() + "\n")
        subprocess.run([
            str(BIN), str(inp), str(out),
            "--max-global-dim", str(K),
            "--oracle", oracle,
            "--schedule", schedule,
            "--order", order,
            "--report", str(rep),
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return out.read_text(), json.loads(rep.read_text())


def parse_edges(text: str):
    edges = []
    for line in text.strip().splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        u, v, w = line.split()
        u, v, w = int(u), int(v), float(w)
        if u > v:
            u, v = v, u
        edges.append((u, v, w))
    return sorted(edges)


def write_edges(path: Path, edges):
    with path.open("w") as f:
        for u, v, w in sorted(edges):
            f.write(f"{u} {v} {w:.17g}\n")


def read_edges(path: Path):
    return parse_edges(path.read_text())


def run_trim_edges(edges, *, K=2, oracle="hybrid", order="reverse"):
    with tempfile.TemporaryDirectory() as td_s:
        td = Path(td_s)
        inp = td / "in.txt"
        out = td / "out.txt"
        rep = td / "rep.json"
        write_edges(inp, edges)
        subprocess.run([
            str(BIN), str(inp), str(out),
            "--max-global-dim", str(K),
            "--oracle", oracle,
            "--schedule", "staged",
            "--order", order,
            "--report", str(rep),
            "--no-certificate",
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return read_edges(out), json.loads(rep.read_text())


def flag_barcode(n: int, edges, max_h_dim: int):
    # Independent small verifier over F2 for flag filtrations.
    # To compute H_d up to max_h_dim, include simplices up to dimension max_h_dim+1.
    edge_w = {tuple(sorted((u, v))): float(w) for u, v, w in edges}
    simplices = []
    for i in range(n):
        simplices.append(((i,), 0.0, 0))
    for dim in range(1, max_h_dim + 2):
        for comb in itertools.combinations(range(n), dim + 1):
            vals = []
            ok = True
            for a, b in itertools.combinations(comb, 2):
                if (a, b) not in edge_w:
                    ok = False
                    break
                vals.append(edge_w[(a, b)])
            if ok:
                simplices.append((comb, max(vals), dim))
    simplices.sort(key=lambda s: (s[1], s[2], s[0]))
    idx = {s[0]: i for i, s in enumerate(simplices)}

    def xor_sorted(A, B):
        i = j = 0
        C = []
        while i < len(A) or j < len(B):
            if j >= len(B) or (i < len(A) and A[i] < B[j]):
                C.append(A[i]); i += 1
            elif i >= len(A) or B[j] < A[i]:
                C.append(B[j]); j += 1
            else:
                i += 1; j += 1
        return C

    def boundary(simplex):
        verts = simplex[0]
        if len(verts) == 1:
            return []
        return sorted(idx[verts[:k] + verts[k+1:]] for k in range(len(verts)))

    red = [[] for _ in simplices]
    low = {}
    zero = [False] * len(simplices)
    paired = [False] * len(simplices)
    bars = [[] for _ in range(max_h_dim + 1)]

    for j, s in enumerate(simplices):
        col = boundary(s)
        while col and col[-1] in low:
            col = xor_sorted(col, red[low[col[-1]]])
        if not col:
            zero[j] = True
        else:
            l = col[-1]
            low[l] = j
            red[j] = col
            paired[l] = True
            d = simplices[l][2]
            birth, death = simplices[l][1], s[1]
            if d <= max_h_dim and death - birth > EPS:
                bars[d].append((round(birth, 8), round(death, 8)))

    for j, s in enumerate(simplices):
        if zero[j] and not paired[j]:
            d = s[2]
            if d <= max_h_dim:
                bars[d].append((round(s[1], 8), None))

    for b in bars:
        b.sort(key=lambda x: (x[0], math.inf if x[1] is None else x[1]))
    return bars


def test_triangle_k1_removes_one_edge():
    _, rep = run_trim("""
        0 1 0
        0 2 0
        1 2 0
    """, K=1)
    assert rep["initial_edges"] == 3
    assert rep["final_edges"] == 2
    assert rep["removed_count"] == 1


def test_square_no_diagonal_no_k1_removal():
    _, rep = run_trim("""
        0 1 0
        1 2 0
        2 3 0
        0 3 0
    """, K=1)
    assert rep["removed_count"] == 0


def test_k2_tetrahedron_removes_some_edge():
    _, rep = run_trim("""
        0 1 0
        0 2 0
        0 3 0
        1 2 0
        1 3 0
        2 3 0
    """, K=2, oracle="hybrid")
    assert rep["removed_count"] >= 1
    assert rep["lower_link_checked_degrees"] == [-1, 0, 1]




def test_k1_homology_delay_can_shift_edge():
    out, rep = run_trim("""
        0 1 0
        0 2 0
        1 2 0
        0 3 0
        1 3 0
        2 3 0
        0 4 1
        1 4 1
    """, K=1, oracle="homology-delay", order="forward")
    assert rep["delayed_count"] >= 1
    assert any(r.get("action") == "delay" and abs(r["new_w"] - 1.0) < 1e-8 for r in rep["removed_edges"])


def test_k2_homology_delay_random_small_preserves_ph_with_internal_verifier():
    random.seed(24680)
    for _ in range(8):
        n = random.randint(5, 7)
        edges = []
        for i in range(n):
            for j in range(i + 1, n):
                edges.append((i, j, random.random()))
        reduced, rep = run_trim_edges(edges, K=2, oracle="homology-delay", order="forward")
        b0 = flag_barcode(n, edges, 2)
        b1 = flag_barcode(n, reduced, 2)
        assert b0 == b1, (n, rep, b0, b1)

def test_k2_random_small_preserves_ph_with_internal_verifier():
    random.seed(12345)
    for _ in range(20):
        n = random.randint(5, 8)
        edges = []
        for i in range(n):
            for j in range(i + 1, n):
                edges.append((i, j, random.random()))
        reduced, rep = run_trim_edges(edges, K=2)
        b0 = flag_barcode(n, edges, 2)
        b1 = flag_barcode(n, reduced, 2)
        assert b0 == b1, (n, rep, b0, b1)


def test_k3_random_tiny_preserves_ph_with_internal_verifier():
    # Experimental K=3 backend. Keep this tiny: independent verifier includes
    # flag simplices up to dimension 4.
    random.seed(54321)
    for _ in range(8):
        n = random.randint(5, 7)
        edges = []
        for i in range(n):
            for j in range(i + 1, n):
                edges.append((i, j, random.random()))
        reduced, rep = run_trim_edges(edges, K=3)
        assert rep["lower_link_checked_degrees"] == [-1, 0, 1, 2]
        b0 = flag_barcode(n, edges, 3)
        b1 = flag_barcode(n, reduced, 3)
        assert b0 == b1, (n, rep, b0, b1)


def main():
    compile_cpp()
    tests = [
        test_triangle_k1_removes_one_edge,
        test_square_no_diagonal_no_k1_removal,
        test_k2_tetrahedron_removes_some_edge,
        test_k1_homology_delay_can_shift_edge,
        test_k2_homology_delay_random_small_preserves_ph_with_internal_verifier,
        test_k2_random_small_preserves_ph_with_internal_verifier,
        test_k3_random_tiny_preserves_ph_with_internal_verifier,
    ]
    for t in tests:
        t()
        print(f"PASS {t.__name__}")
    print("\nAll K=0/K=1/K=2 and experimental K=3 C++ trim-engine tests passed.")


if __name__ == "__main__":
    main()
