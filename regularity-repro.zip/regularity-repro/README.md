# Regularity / Homological Trimming Reproducibility Code

This repository contains anonymized code for reproducing the computational experiments associated with the paper.  It has two independent parts:

1. **Homological trimming experiments** for edge-filtered flag complexes.
2. **RSD structural-descriptor experiments** used in the preliminary application appendix.

The repository is intentionally minimal: source code, runnable experiment scripts, small reference outputs, and no paper drafts, logs, compiled binaries, or old run folders.

## Repository layout

```text
.
├── CMakeLists.txt / Makefile          # C++ build for ht_trim
├── include/ht/                        # C++ headers
├── src/                               # C++ implementation
├── python/
│   ├── run_paper_success_suite.py      # trimming experiment suite
│   ├── rsd_synthetic_descriptor_experiment.py
│   └── helper modules
├── scripts/
│   ├── run_trimming_smoke.sh           # fast trimming sanity run, no PH timings
│   ├── run_trimming_paper.sh           # larger trimming experiments
│   ├── run_rsd_structure.sh            # RSD structural-descriptor experiment
│   └── clean_outputs.sh
├── tests/test_ht_trim_engine.py        # C++ engine smoke tests
├── reference/                          # small reference outputs from smoke/RSD runs
└── results/                            # generated locally; ignored by git
```

## Requirements

C++:

- A C++17 compiler (`g++`, `clang++`, or equivalent)
- `make` or `cmake`

Python:

```bash
python3 -m pip install -r requirements.txt
```

`ripser` is only needed when running PH timing/verification jobs.  The default trimming smoke test uses `--skip-ph`, so it does not compute persistence diagrams.

## Quick smoke test

From the repository root:

```bash
bash scripts/run_trimming_smoke.sh
bash scripts/run_rsd_structure.sh
```

Expected outputs:

```text
results/trimming_smoke/
results/rsd_structure/
```

The trimming smoke test builds the C++ binary, runs internal engine tests, checks Python syntax, and executes the small `smoke` profile of the trimming experiment suite.  The RSD script regenerates the synthetic descriptor tables and diagnostic plots.

## Reproducing the trimming experiments

Fast smoke profile:

```bash
python3 python/run_paper_success_suite.py \
  --profile smoke \
  --skip-ph \
  --out-dir results/trimming_smoke
```

Paper-scale profile:

```bash
bash scripts/run_trimming_paper.sh
```

The paper-scale run writes CSV files such as:

```text
A_value_add_large_sparse_raw.csv
A_value_add_large_sparse_summary.csv
B_scaling_n_points_raw.csv
B_scaling_n_points_summary.csv
C_scaling_p_degree_raw.csv
C_scaling_p_degree_summary.csv
D_sparsity_envelope_raw.csv
D_sparsity_envelope_summary.csv
E_high_p_sparse_success_raw.csv
E_high_p_sparse_success_summary.csv
ALL_paper_success_jobs.csv
ALL_paper_success_summary.csv
RUN_MANIFEST.json
```

The main configurable options are:

```bash
python3 python/run_paper_success_suite.py --help
```

Useful flags include `--profile`, `--seeds`, `--skip-ph`, `--ph-timeout`, `--trim-timeout`, `--count-simplices`, and `--resume`.

## Reproducing the RSD structural-descriptor experiment

```bash
python3 python/rsd_synthetic_descriptor_experiment.py \
  --out-dir results/rsd_structure \
  --num-seeds 20
```

This writes:

```text
rsd_family_summaries.csv
rsd_family_aggregate.csv
rsd_feature_set_accuracy.csv
rsd_classification_confusion.csv
fig_regular_fraction.png
fig_median_margin.png
fig_h1_right_blocker.png
```

The experiment is synthetic and deliberately controlled.  Its purpose is to illustrate that RSD summaries can behave as structured descriptors; it should not be read as application-level validation.

## Custom experiments

For new trimming experiments, edit or extend the case profiles in `python/run_paper_success_suite.py`, especially the `profile_specs` function and the graph generators used by `make_graph`.

For new RSD descriptor experiments, edit the generators in `python/rsd_synthetic_descriptor_experiment.py` or add another family to the `generators` list in `run_experiment`.

## Reference outputs

The `reference/` directory contains small CSV outputs from earlier smoke/RSD runs.  They are intended only as sanity references; timings can vary across machines.

## Notes on anonymization

This is an anonymous-review version.  The repository intentionally omits author names, personal paths, logs, paper drafts, and compiled binaries.  Upstream third-party license/attribution material should be restored or reviewed before any non-anonymous public archival release.
