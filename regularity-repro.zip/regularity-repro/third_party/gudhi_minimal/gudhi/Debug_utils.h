/* Minimal compatibility header for the standalone GUDHI edge-collapser benchmark.
 *
 * The full GUDHI library provides gudhi/Debug_utils.h.  For this isolated
 * benchmark, Flag_complex_edge_collapser.h only needs assert support.
 *
 * This compatibility shim is not a replacement for GUDHI.
 */
#ifndef GUDHI_MINIMAL_DEBUG_UTILS_H_
#define GUDHI_MINIMAL_DEBUG_UTILS_H_

#include <cassert>

#endif  // GUDHI_MINIMAL_DEBUG_UTILS_H_
