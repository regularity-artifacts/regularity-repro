# Minimal GUDHI edge-collapser header for benchmarking

This directory contains a small standalone copy/adaptation of GUDHI's
`Flag_complex_edge_collapser.h`, plus a minimal `Debug_utils.h` shim.

It is included only to make the domination-vs-GUDHI benchmark easy to compile
without a full GUDHI installation.

The original GUDHI file is released under the MIT license:
https://gudhi.inria.fr/licensing/

Original file:
https://gudhi.inria.fr/doc/latest/_flag__complex__edge__collapser_8h_source.html

Copyright (C) 2020 Inria.
