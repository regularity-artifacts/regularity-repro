# Minimal Boost subset for the bundled GUDHI edge collapser

This directory contains only the Boost headers actually required to compile
`third_party/gudhi_minimal/gudhi/Flag_complex_edge_collapser.h` (which uses
`boost::container::flat_map` and `boost::container::flat_set`), plus their
transitive dependencies (`boost/move`, `boost/intrusive`, `boost/core`,
`boost/config`, `boost/assert`, `boost/static_assert`, `boost/throw_exception`,
`boost/mp11`, `boost/predef`, `boost/preprocessor`).

The exact file set was determined by compiling `src/gudhi_collapse_mode.cpp`
against a full Boost checkout with `-MM` and vendoring exactly the headers
that were actually pulled in (105 files, ~1.6 MB), rather than copying entire
Boost libraries. This keeps the dependency footprint small and avoids
requiring a system Boost installation to build `ht_trim`.

Boost is distributed under the Boost Software License:
https://www.boost.org/LICENSE_1_0.txt

Source: https://github.com/boostorg (container, move, intrusive, core, config,
assert, static_assert, throw_exception, mp11, predef, preprocessor).
